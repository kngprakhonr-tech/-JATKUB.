import React, { useState } from 'react';
import { Gamepad2, ShoppingCart, User, Menu, X, MessageSquare, Wallet, Bell, LogOut } from 'lucide-react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'motion/react';
import { useBalance } from '../context/BalanceContext';
import { useAuth } from '../context/AuthContext';

export default function Navbar() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const { balance } = useBalance();
  const { user, signOut } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();

  // Hide navbar on login and seller hub pages
  if (location.pathname === '/login' || location.pathname === '/seller-hub') return null;

  const handleSignOut = async () => {
    await signOut();
    navigate('/login');
  };

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 glass border-b border-white/5">
      <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
        <Link to="/" className="flex items-center gap-2 group">
          <div className="w-10 h-10 bg-brand-primary rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform">
            <Gamepad2 className="text-brand-dark w-6 h-6" />
          </div>
          <span className="text-xl font-display font-black tracking-tighter">JAKUB</span>
        </Link>

        {/* Desktop Nav */}
        <div className="hidden md:flex items-center gap-8 text-sm font-medium text-gray-400">
          <Link to="/marketplace" className="hover:text-brand-primary transition-colors">Marketplace</Link>
          <Link to="/seller-hub" className="hover:text-brand-primary transition-colors">Seller Hub</Link>
          <Link to="/messages" className="hover:text-brand-primary transition-colors">Messages</Link>
          <Link to="/wallet" className="hover:text-brand-primary transition-colors">Escrow</Link>
        </div>

        <div className="flex items-center gap-4">
          <Link to="/wallet" className="hidden sm:flex items-center gap-2 px-3 py-1.5 bg-white/5 border border-white/10 rounded-xl hover:bg-white/10 transition-all group">
            <Wallet className="w-4 h-4 text-brand-primary" />
            <span className="text-sm font-display font-black">฿{(balance || 0).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
          </Link>

          <button className="p-2 hover:bg-white/5 rounded-full transition-colors relative text-gray-400">
            <Bell className="w-5 h-5" />
            <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-brand-primary rounded-full border-2 border-brand-dark"></span>
          </button>

          <Link to="/messages" className="p-2 hover:bg-white/5 rounded-full transition-colors relative text-gray-400">
            <MessageSquare className="w-5 h-5" />
            <span className="absolute top-0 right-0 w-4 h-4 bg-brand-primary text-brand-dark text-[10px] font-bold rounded-full flex items-center justify-center">1</span>
          </Link>

          {user ? (
            <button 
              onClick={handleSignOut}
              className="flex items-center gap-2 p-1 pr-3 hover:bg-white/5 rounded-full transition-colors group border border-transparent hover:border-white/10"
            >
              <div className="w-8 h-8 bg-brand-surface rounded-full flex items-center justify-center overflow-hidden border border-white/10">
                <img src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${user.email}`} alt="Avatar" />
              </div>
              <LogOut className="w-4 h-4 text-gray-400 group-hover:text-red-500" />
            </button>
          ) : (
            <Link to="/login" className="flex items-center gap-2 p-1 pr-3 hover:bg-white/5 rounded-full transition-colors group border border-transparent hover:border-white/10">
              <div className="w-8 h-8 bg-brand-surface rounded-full flex items-center justify-center overflow-hidden border border-white/10">
                <User className="w-4 h-4 text-gray-400" />
              </div>
            </Link>
          )}

          <button 
            className="md:hidden p-2 hover:bg-white/5 rounded-lg transition-colors"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isMenuOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="md:hidden absolute top-16 left-0 right-0 bg-brand-surface border-b border-white/10 p-4 flex flex-col gap-4"
          >
            <Link to="/marketplace" onClick={() => setIsMenuOpen(false)} className="text-lg font-medium">Marketplace</Link>
            <Link to="/seller-hub" onClick={() => setIsMenuOpen(false)} className="text-lg font-medium">Seller Hub</Link>
            <Link to="/messages" onClick={() => setIsMenuOpen(false)} className="text-lg font-medium">Messages</Link>
            <a href="#" className="text-lg font-medium">Escrow</a>
            <a href="#" className="text-lg font-medium">Support</a>
            <hr className="border-white/5" />
            {user ? (
              <button onClick={handleSignOut} className="w-full py-3 bg-red-500/10 text-red-500 font-bold rounded-xl">Log Out</button>
            ) : (
              <Link to="/login" onClick={() => setIsMenuOpen(false)} className="w-full py-3 bg-brand-primary text-brand-dark font-bold rounded-xl text-center">Login / Sign Up</Link>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
}
