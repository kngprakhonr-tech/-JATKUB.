import React from 'react';
import { Gamepad2, Globe, TrendingUp, ShieldCheck } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function Footer() {
  return (
    <footer className="bg-brand-surface border-t border-white/5 mt-20">
      <div className="max-w-7xl mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12">
          <div className="space-y-6">
            <Link to="/" className="flex items-center gap-2">
              <div className="w-8 h-8 bg-brand-primary rounded flex items-center justify-center">
                <Gamepad2 className="text-brand-dark w-5 h-5" />
              </div>
              <span className="text-xl font-display font-bold tracking-tighter">JAKUB</span>
            </Link>
            <p className="text-gray-500 text-sm leading-relaxed">
              The world's leading marketplace for gamers. Secure, fast, and reliable trading for all your gaming needs.
            </p>
          </div>

          <div>
            <h4 className="font-bold mb-6">Marketplace</h4>
            <ul className="space-y-4 text-sm text-gray-500">
              <li><Link to="/marketplace" className="hover:text-brand-primary transition-colors">All Games</Link></li>
              <li><Link to="/marketplace?category=Accounts" className="hover:text-brand-primary transition-colors">Accounts</Link></li>
              <li><Link to="/marketplace?category=Items" className="hover:text-brand-primary transition-colors">Items</Link></li>
              <li><Link to="/marketplace?category=Boosting" className="hover:text-brand-primary transition-colors">Boosting</Link></li>
            </ul>
          </div>

          <div>
            <h4 className="font-bold mb-6">Company</h4>
            <ul className="space-y-4 text-sm text-gray-500">
              <li><a href="#" className="hover:text-brand-primary transition-colors">About Us</a></li>
              <li><a href="#" className="hover:text-brand-primary transition-colors">Careers</a></li>
              <li><a href="#" className="hover:text-brand-primary transition-colors">Press</a></li>
              <li><a href="#" className="hover:text-brand-primary transition-colors">Blog</a></li>
            </ul>
          </div>

          <div>
            <h4 className="font-bold mb-6">Support</h4>
            <ul className="space-y-4 text-sm text-gray-500">
              <li><a href="#" className="hover:text-brand-primary transition-colors">Help Center</a></li>
              <li><a href="#" className="hover:text-brand-primary transition-colors">Safety Tips</a></li>
              <li><a href="#" className="hover:text-brand-primary transition-colors">Contact Us</a></li>
              <li><a href="#" className="hover:text-brand-primary transition-colors">Terms of Service</a></li>
            </ul>
          </div>
        </div>

        <div className="pt-12 mt-12 border-t border-white/5 flex flex-col md:flex-row items-center justify-between gap-6">
          <p className="text-gray-500 text-sm">© 2026 JAKUB Marketplace. All rights reserved.</p>
          <div className="flex items-center gap-6">
            <a href="#" className="text-gray-500 hover:text-white transition-colors"><Globe className="w-5 h-5" /></a>
            <a href="#" className="text-gray-500 hover:text-white transition-colors"><TrendingUp className="w-5 h-5" /></a>
            <a href="#" className="text-gray-500 hover:text-white transition-colors"><ShieldCheck className="w-5 h-5" /></a>
          </div>
        </div>
      </div>
    </footer>
  );
}
