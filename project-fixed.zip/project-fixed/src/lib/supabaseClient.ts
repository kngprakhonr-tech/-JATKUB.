import { createClient } from '@supabase/supabase-js'

// ข้อมูลจาก Supabase ของคุณ
const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || 'https://pdhjyedijaieomhkbduo.supabase.co'
// แนะนำให้ใส่ Key ไว้ใน Environment Variable (Secrets) เพื่อความปลอดภัย
const supabaseKey = import.meta.env.VITE_SUPABASE_ANON_KEY || 'ก๊อปปี้_Publishable_key_มายาวๆ_มาวางตรงนี้'

export const supabase = createClient(supabaseUrl, supabaseKey)
