import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import HomePage from './pages/Home';
import MarketplacePage from './pages/Marketplace';
import SellPage from './pages/Sell';
import MessagesPage from './pages/Messages';
import WalletPage from './pages/Wallet';
import LoginPage from './pages/Login';
import ProfilePage from './pages/Profile';
import SellerDashboard from './pages/SellerDashboard';
import SalesHistoryPage from './pages/SalesHistory';
import InventoryPage from './pages/Inventory';
import { Listing } from './types';
import { supabase } from './lib/supabaseClient';

export default function App() {
  const [listings, setListings] = useState<Listing[]>([]);

  useEffect(() => {
    const fetchProducts = async () => {
      const { data, error } = await supabase
        .from('products')
        .select('*');

      if (error) {
        console.error('Error fetching products:', error);
        return;
      }

      if (data) {
        const mappedListings: Listing[] = data.map((product: any) => ({
          id: product.id,
          title: product.name,
          game: 'Unknown Game', // Default
          price: Number(product.price),
          seller: 'Unknown Seller', // Default
          rating: 0, // Default
          image: product.image_url || 'https://picsum.photos/seed/product/400/300',
          category: 'Item', // Default
          description: product.description,
          status: product.status === 'available' ? 'Available' : 'Sold',
        }));
        setListings(mappedListings);
      }
    };

    fetchProducts();
  }, []);

  return (
    <Router>
      <div className="min-h-screen bg-brand-dark text-gray-100 selection:bg-brand-primary selection:text-brand-dark">
        <Navbar />
        <Routes>
          <Route path="/" element={<HomePage trendingListings={listings.slice(0, 4)} />} />
          <Route path="/marketplace" element={<MarketplacePage />} />
          <Route path="/sell" element={<SellPage />} />
          <Route path="/messages" element={<MessagesPage />} />
          <Route path="/wallet" element={<WalletPage />} />
          <Route path="/login" element={<LoginPage />} />
          <Route path="/profile" element={<ProfilePage />} />
          <Route path="/seller-hub" element={<SellerDashboard />} />
          <Route path="/sales-history" element={<SalesHistoryPage />} />
          <Route path="/inventory" element={<InventoryPage />} />
        </Routes>
        <Footer />
      </div>
    </Router>
  );
}
