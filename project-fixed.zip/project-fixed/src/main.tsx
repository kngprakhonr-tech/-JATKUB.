import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';
import { AuthProvider } from './context/AuthContext.tsx';
import { BalanceProvider } from './context/BalanceContext.tsx';
import { ErrorBoundary } from './components/ErrorBoundary.tsx';

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <ErrorBoundary>
      <AuthProvider>
        <BalanceProvider>
          <App />
        </BalanceProvider>
      </AuthProvider>
    </ErrorBoundary>
  </StrictMode>,
);
