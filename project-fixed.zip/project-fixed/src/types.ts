export interface Listing {
  id: string;
  title: string;
  game: string;
  price: number;
  seller: string;
  rating: number;
  image: string;
  category: 'Account' | 'Item' | 'Service';
  description?: string;
  status?: 'Available' | 'In Escrow' | 'Sold';
}

export interface Message {
  id: string;
  senderId: string;
  text: string;
  timestamp: string;
  isMe: boolean;
}

export interface Chat {
  id: string;
  participant: {
    name: string;
    avatar: string;
    status: 'online' | 'offline' | 'active in trade';
  };
  role: 'buyer' | 'seller';
  lastMessage: string;
  lastMessageTime: string;
  messages: Message[];
  orderDetail?: {
    itemTitle: string;
    itemImage: string;
    price: number;
    status: string;
  };
}

export interface Transaction {
  id: string;
  type: 'Deposit' | 'Withdraw' | 'Sale' | 'Purchase';
  amount: number;
  method?: string;
  status: 'Completed' | 'Pending' | 'Rejected';
  timestamp: string;
  description: string;
}

export interface WalletState {
  balance: number;
  transactions: Transaction[];
}

export interface SellerStats {
  totalEarnings: number;
  pendingPayouts: number;
  earningsGrowth: number;
  nextReleaseTime: string;
}

export interface ActiveListing {
  id: string;
  title: string;
  game: string;
  price: number;
  views: number;
  image: string;
  status: 'Active' | 'Sold' | 'In Escrow';
}

export interface EscrowTransaction {
  id: string;
  buyer: string;
  item: string;
  price: number;
  status: 'Asset Delivered' | 'Awaiting Confirmation' | 'Funds Releasing';
  step: number;
  totalSteps: number;
}

export interface SalesHistoryItem {
  id: string;
  item: string;
  buyer: string;
  price: number;
  date: string;
  status: 'Completed' | 'Refunded' | 'Cancelled';
  image: string;
}

export type Category = 'All' | 'Accounts' | 'Items' | 'Boosting' | 'Currency';
