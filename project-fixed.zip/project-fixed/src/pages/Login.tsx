import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { 
  ShieldCheck, 
  User, 
  Key, 
  Gamepad2, 
  Globe, 
  Chrome,
  AlertCircle,
  Eye,
  EyeOff
} from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { cn } from '../lib/utils';
import { supabase } from '../lib/supabaseClient';
import { useAuth } from '../context/AuthContext';

export default function LoginPage() {
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  const { user } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (user) {
      navigate('/');
    }
  }, [user, navigate]);

  const handleAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    try {
      if (isLogin) {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
      } else {
        const { error } = await supabase.auth.signUp({ email, password });
        if (error) throw error;
        alert('สมัครสมาชิกสำเร็จ! โปรดตรวจสอบอีเมลเพื่อยืนยันตัวตน');
      }
      navigate('/');
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const resendConfirmation = async () => {
    setLoading(true);
    setError(null);
    try {
      const { error } = await supabase.auth.resend({
        type: 'signup',
        email: email,
      });
      if (error) throw error;
      alert('ส่งอีเมลยืนยันใหม่เรียบร้อยแล้ว โปรดตรวจสอบอีเมลของคุณ');
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-brand-dark flex flex-col items-center justify-center p-6 relative overflow-hidden">
      <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(circle_at_center,rgba(0,212,255,0.05)_0%,transparent_70%)] pointer-events-none" />
      <div className="absolute -top-24 -left-24 w-96 h-96 bg-brand-primary/10 rounded-full blur-[100px] pointer-events-none" />
      <div className="absolute -bottom-24 -right-24 w-96 h-96 bg-brand-secondary/10 rounded-full blur-[100px] pointer-events-none" />

      <Link to="/" className="flex items-center gap-3 mb-12 relative group">
        <div className="w-12 h-12 bg-brand-primary rounded-2xl flex items-center justify-center shadow-[0_0_30px_rgba(0,212,255,0.3)] group-hover:scale-110 transition-transform">
          <Gamepad2 className="text-brand-dark w-7 h-7" />
        </div>
        <span className="text-3xl font-display font-black tracking-tighter text-white">JAKUB</span>
      </Link>

      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-md relative"
      >
        <div className="absolute -top-6 left-1/2 -translate-x-1/2 px-4 py-2 bg-brand-surface border border-white/10 rounded-xl flex items-center gap-2 shadow-2xl z-10">
          <ShieldCheck className="text-brand-primary w-4 h-4" />
          <span className="text-[10px] font-bold uppercase tracking-widest text-brand-primary">Escrow Protected</span>
        </div>

        <form onSubmit={handleAuth} className="bg-brand-surface/50 backdrop-blur-xl border border-white/5 rounded-[40px] p-10 space-y-8 shadow-2xl">
          <div className="space-y-2 text-center">
            <h1 className="text-3xl font-display font-black">
              {isLogin ? 'Welcome Back, Operative' : 'Join the Bastion'}
            </h1>
            <p className="text-sm text-gray-500">
              {isLogin ? 'Re-authorize to access the Neon Bastion.' : 'Create your secure identity on the marketplace.'}
            </p>
          </div>

          {error && (
            <div className="bg-red-500/10 border border-red-500/20 text-red-500 p-4 rounded-2xl text-sm space-y-2">
              <div className="flex items-center gap-2">
                <AlertCircle className="w-4 h-4" />
                {error}
              </div>
              {error.includes('Email not confirmed') && (
                <button 
                  type="button"
                  onClick={resendConfirmation}
                  className="w-full py-2 bg-red-500/20 hover:bg-red-500/30 text-red-200 rounded-xl text-xs font-bold uppercase tracking-widest transition-colors"
                >
                  ส่งอีเมลยืนยันใหม่อีกครั้ง
                </button>
              )}
            </div>
          )}

          <div className="space-y-6">
            <div className="space-y-2">
              <label className="text-[10px] font-bold text-gray-500 uppercase tracking-widest ml-1">Email</label>
              <div className="relative">
                <User className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
                <input 
                  type="email" 
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="operative@bastion.net"
                  className="w-full bg-brand-dark/50 border border-white/5 rounded-2xl py-4 pl-12 pr-4 focus:outline-none focus:ring-2 focus:ring-brand-primary/50 transition-all text-sm font-medium"
                  required
                />
              </div>
            </div>

            <div className="space-y-2">
              <div className="flex justify-between items-center ml-1">
                <label className="text-[10px] font-bold text-gray-500 uppercase tracking-widest">Access Key</label>
              </div>
              <div className="relative">
                <Key className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
                <input 
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••••••"
                  className="w-full bg-brand-dark/50 border border-white/5 rounded-2xl py-4 pl-12 pr-12 focus:outline-none focus:ring-2 focus:ring-brand-primary/50 transition-all text-sm font-medium"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-500 hover:text-brand-primary transition-colors"
                >
                  {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                </button>
              </div>
            </div>

            <button 
              type="submit"
              disabled={loading}
              className="w-full py-5 bg-brand-secondary text-white font-display font-black text-xl rounded-2xl hover:scale-[1.02] active:scale-[0.98] transition-all shadow-[0_0_30px_rgba(0,212,255,0.2)] disabled:opacity-50"
            >
              {loading ? 'PROCESSING...' : (isLogin ? 'SECURE ACCESS' : 'CREATE IDENTITY')}
            </button>
          </div>

          <div className="text-center">
            <button 
              type="button"
              onClick={() => setIsLogin(!isLogin)}
              className="text-xs text-gray-500 hover:text-brand-primary transition-colors"
            >
              {isLogin ? "New to the bastion? " : "Already an operative? "}
              <span className="font-bold text-brand-primary underline decoration-brand-primary/30">
                {isLogin ? "Create an Account" : "Secure Access"}
              </span>
            </button>
          </div>
        </form>
      </motion.div>

      <div className="mt-12 flex gap-8 text-[10px] font-bold text-gray-600 uppercase tracking-widest">
        <a href="#" className="hover:text-gray-400 transition-colors">Privacy Policy</a>
        <a href="#" className="hover:text-gray-400 transition-colors">Terms of Service</a>
        <a href="#" className="hover:text-gray-400 transition-colors">Security Audit</a>
      </div>
      <p className="mt-8 text-[10px] text-gray-700 font-bold uppercase tracking-widest">
        © 2024 JAKUB. THE NEON BASTION SECURED.
      </p>
    </div>
  );
}
