import React, { useState } from 'react';
import { 
  Search, 
  Phone, 
  MoreVertical, 
  Paperclip, 
  Send, 
  CheckCheck, 
  Clock, 
  ShieldCheck, 
  ChevronRight, 
  AlertCircle,
  Gamepad2,
  MessageSquare,
  Package,
  Settings,
  Zap
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { MOCK_CHATS } from '../constants';
import { Chat } from '../types';
import { cn } from '../lib/utils';

export default function MessagesPage() {
  const [activeTab, setActiveTab] = useState<'buyer' | 'seller'>('buyer');
  const filteredChats = MOCK_CHATS.filter(chat => chat.role === activeTab);
  const [selectedChat, setSelectedChat] = useState<Chat>(filteredChats[0] || MOCK_CHATS[0]);
  const [messageText, setMessageText] = useState('');

  // Update selected chat when tab changes if current selection is not in the new tab
  const handleTabChange = (tab: 'buyer' | 'seller') => {
    setActiveTab(tab);
    const newFiltered = MOCK_CHATS.filter(chat => chat.role === tab);
    if (newFiltered.length > 0) {
      setSelectedChat(newFiltered[0]);
    }
  };

  return (
    <div className="flex h-screen pt-16 bg-brand-dark overflow-hidden">
      {/* Sidebar - Recent Chats */}
      <div className="w-80 border-r border-white/5 flex flex-col bg-brand-surface/50">
        <div className="p-4 border-b border-white/5 space-y-4">
          <div className="flex bg-white/5 p-1 rounded-xl">
            <button 
              onClick={() => handleTabChange('buyer')}
              className={cn(
                "flex-1 py-2 text-xs font-bold uppercase tracking-widest rounded-lg transition-all",
                activeTab === 'buyer' ? "bg-brand-primary text-brand-dark shadow-lg" : "text-gray-500 hover:text-gray-300"
              )}
            >
              Buying
            </button>
            <button 
              onClick={() => handleTabChange('seller')}
              className={cn(
                "flex-1 py-2 text-xs font-bold uppercase tracking-widest rounded-lg transition-all",
                activeTab === 'seller' ? "bg-brand-primary text-brand-dark shadow-lg" : "text-gray-500 hover:text-gray-300"
              )}
            >
              Selling
            </button>
          </div>
          
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
            <input 
              type="text" 
              placeholder="Search chats..."
              className="w-full bg-white/5 border border-white/10 rounded-xl py-2 pl-10 pr-4 text-sm focus:outline-none focus:ring-1 focus:ring-brand-primary/50"
            />
          </div>
        </div>

        <div className="flex-1 overflow-y-auto">
          {filteredChats.length > 0 ? (
            filteredChats.map((chat) => (
              <button
                key={chat.id}
                onClick={() => setSelectedChat(chat)}
                className={cn(
                  "w-full p-4 flex items-start gap-3 transition-colors border-l-2",
                  selectedChat.id === chat.id 
                    ? "bg-brand-primary/5 border-brand-primary" 
                    : "hover:bg-white/5 border-transparent"
                )}
              >
                <div className="relative">
                  <img 
                    src={chat.participant.avatar} 
                    alt={chat.participant.name} 
                    className="w-12 h-12 rounded-xl bg-white/5"
                  />
                  <div className={cn(
                    "absolute -bottom-1 -right-1 w-3 h-3 rounded-full border-2 border-brand-dark",
                    chat.participant.status === 'online' ? "bg-green-500" : 
                    chat.participant.status === 'active in trade' ? "bg-brand-primary" : "bg-gray-500"
                  )} />
                </div>
                <div className="flex-1 text-left min-w-0">
                  <div className="flex justify-between items-center mb-1">
                    <span className="font-bold text-sm truncate">{chat.participant.name}</span>
                    <span className="text-[10px] text-gray-500">{chat.lastMessageTime}</span>
                  </div>
                  <p className="text-xs text-gray-400 truncate">{chat.lastMessage}</p>
                </div>
              </button>
            ))
          ) : (
            <div className="p-8 text-center space-y-2 opacity-30">
              <MessageSquare className="w-8 h-8 mx-auto" />
              <p className="text-xs">No {activeTab} chats found</p>
            </div>
          )}
        </div>
      </div>

      {/* Main Chat Area */}
      <div className="flex-1 flex flex-col bg-brand-dark">
        {/* Chat Header */}
        <div className="h-16 border-b border-white/5 flex items-center justify-between px-6 bg-brand-surface/30">
          <div className="flex items-center gap-3">
            <div className="relative">
              <img 
                src={selectedChat.participant.avatar} 
                alt={selectedChat.participant.name} 
                className="w-10 h-10 rounded-lg bg-white/5"
              />
            </div>
            <div>
              <h3 className="font-bold text-sm">{selectedChat.participant.name}</h3>
              <div className="flex items-center gap-1.5">
                <div className={cn(
                  "w-1.5 h-1.5 rounded-full",
                  selectedChat.participant.status === 'online' ? "bg-green-500" : 
                  selectedChat.participant.status === 'active in trade' ? "bg-brand-primary" : "bg-gray-500"
                )} />
                <span className="text-[10px] text-brand-primary uppercase font-bold tracking-wider">
                  {selectedChat.participant.status}
                </span>
              </div>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <button className="p-2 hover:bg-white/5 rounded-lg transition-colors text-gray-400">
              <Phone className="w-5 h-5" />
            </button>
            <button className="p-2 hover:bg-white/5 rounded-lg transition-colors text-gray-400">
              <MoreVertical className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Messages List */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          <div className="flex justify-center">
            <span className="px-3 py-1 bg-white/5 rounded-full text-[10px] font-bold text-gray-500 uppercase tracking-widest">Today</span>
          </div>

          {selectedChat.messages.map((msg) => (
            <div 
              key={msg.id} 
              className={cn(
                "flex items-end gap-3",
                msg.isMe ? "flex-row-reverse" : "flex-row"
              )}
            >
              {!msg.isMe && (
                <img 
                  src={selectedChat.participant.avatar} 
                  className="w-8 h-8 rounded-lg bg-white/5 mb-1" 
                  alt=""
                />
              )}
              <div className="max-w-[70%] space-y-1">
                <div className={cn(
                  "p-4 rounded-2xl text-sm leading-relaxed",
                  msg.isMe 
                    ? "bg-brand-secondary/80 text-white rounded-br-none" 
                    : "bg-brand-surface border border-white/5 text-gray-200 rounded-bl-none"
                )}>
                  {msg.text}
                </div>
                <div className={cn(
                  "flex items-center gap-1 text-[10px] text-gray-500",
                  msg.isMe ? "justify-end" : "justify-start"
                )}>
                  <span>{msg.timestamp}</span>
                  {msg.isMe && <CheckCheck className="w-3 h-3 text-brand-primary" />}
                </div>
              </div>
              {msg.isMe && (
                <div className="w-6 h-6 bg-brand-primary/20 rounded flex items-center justify-center text-[10px] font-bold text-brand-primary mb-1">
                  J
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Message Input */}
        <div className="p-4 border-t border-white/5 bg-brand-surface/30">
          <div className="max-w-4xl mx-auto flex items-center gap-3 bg-white/5 border border-white/10 rounded-2xl p-2">
            <button className="p-2 hover:bg-white/5 rounded-xl text-gray-500 transition-colors">
              <Paperclip className="w-5 h-5" />
            </button>
            <input 
              type="text" 
              placeholder={`Type a message to ${selectedChat.participant.name}...`}
              className="flex-1 bg-transparent border-none focus:ring-0 text-sm py-2"
              value={messageText}
              onChange={(e) => setMessageText(e.target.value)}
            />
            <button className="p-2 bg-brand-secondary text-white rounded-xl hover:scale-105 transition-transform">
              <Send className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>

      {/* Right Sidebar - Order Details */}
      <div className="w-80 border-l border-white/5 bg-brand-surface/50 p-6 overflow-y-auto hidden xl:block">
        <h2 className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-6">Order Details</h2>

        {selectedChat.orderDetail ? (
          <div className="space-y-8">
            <div className="space-y-4">
              <div className="relative aspect-video rounded-xl overflow-hidden border border-white/10">
                <img 
                  src={selectedChat.orderDetail.itemImage} 
                  alt={selectedChat.orderDetail.itemTitle}
                  className="w-full h-full object-cover"
                />
                <div className="absolute top-2 right-2 px-2 py-1 bg-brand-primary/90 backdrop-blur-sm text-brand-dark text-[8px] font-bold rounded uppercase tracking-widest">
                  Verified
                </div>
              </div>
              <div>
                <h3 className="font-bold text-lg leading-tight">{selectedChat.orderDetail.itemTitle}</h3>
                <p className="text-[10px] text-gray-500 uppercase tracking-wider mt-1">Level 450 + Limited Items</p>
              </div>
              <div className="flex justify-between items-end">
                <div>
                  <span className="text-[10px] text-gray-500 uppercase font-bold">Price</span>
                  <div className="text-2xl font-display font-black text-brand-secondary">${selectedChat.orderDetail.price}</div>
                </div>
                <div className="text-right">
                  <span className="text-[10px] text-gray-500 uppercase font-bold">Status</span>
                  <div className="px-2 py-1 bg-brand-primary/10 border border-brand-primary/20 text-brand-primary text-[10px] font-bold rounded-lg mt-1">
                    {selectedChat.orderDetail.status}
                  </div>
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <h4 className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">Trade Timeline</h4>
              <div className="space-y-6 relative before:absolute before:left-[9px] before:top-2 before:bottom-2 before:w-px before:bg-white/10">
                <div className="flex gap-4 relative">
                  <div className="w-5 h-5 rounded-full bg-brand-primary flex items-center justify-center z-10 shrink-0">
                    <CheckCheck className="w-3 h-3 text-brand-dark" />
                  </div>
                  <div>
                    <p className="text-xs font-bold">Payment Sent</p>
                    <p className="text-[10px] text-gray-500">14:01 • Verified by Bastion</p>
                  </div>
                </div>
                <div className="flex gap-4 relative">
                  <div className="w-5 h-5 rounded-full bg-brand-dark border-2 border-brand-primary flex items-center justify-center z-10 shrink-0">
                    <div className="w-1.5 h-1.5 rounded-full bg-brand-primary animate-pulse" />
                  </div>
                  <div>
                    <p className="text-xs font-bold">Awaiting Asset</p>
                    <p className="text-[10px] text-gray-500">Seller is releasing details...</p>
                  </div>
                </div>
                <div className="flex gap-4 relative opacity-30">
                  <div className="w-5 h-5 rounded-full bg-brand-dark border-2 border-white/10 flex items-center justify-center z-10 shrink-0" />
                  <div>
                    <p className="text-xs font-bold">Completion</p>
                    <p className="text-[10px] text-gray-500">Awaiting confirmation</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="space-y-3 pt-6">
              {selectedChat.role === 'buyer' ? (
                <button className="w-full py-4 bg-brand-primary text-brand-dark font-display font-black text-lg rounded-2xl hover:scale-[1.02] active:scale-[0.98] transition-all shadow-[0_0_20px_rgba(0,255,136,0.2)] flex items-center justify-center gap-2">
                  <ShieldCheck className="w-5 h-5" />
                  ยืนยันรับสินค้า
                </button>
              ) : (
                <>
                  <button className="w-full py-4 bg-brand-primary text-brand-dark font-display font-black text-lg rounded-2xl hover:scale-[1.02] active:scale-[0.98] transition-all shadow-[0_0_20px_rgba(0,255,136,0.2)] flex items-center justify-center gap-2">
                    <Zap className="w-5 h-5" />
                    ยืนยันการส่งสินค้า
                  </button>
                  <button className="w-full py-3 bg-white/5 border border-white/10 rounded-xl text-sm font-bold hover:bg-white/10 transition-colors flex items-center justify-center gap-2">
                    <Clock className="w-4 h-4" />
                    รีฟัน (Refund)
                  </button>
                </>
              )}
              
              <button className="w-full py-3 bg-white/5 border border-white/10 rounded-xl text-sm font-bold hover:bg-white/10 transition-colors">
                View Details
              </button>
              <button className="w-full py-3 bg-red-500/10 border border-red-500/20 text-red-500 rounded-xl text-sm font-bold hover:bg-red-500/20 transition-colors flex items-center justify-center gap-2">
                <AlertCircle className="w-4 h-4" />
                Report Dispute
              </button>
            </div>
          </div>
        ) : (
          <div className="h-full flex flex-col items-center justify-center text-center space-y-4 opacity-30">
            <Package className="w-12 h-12" />
            <p className="text-sm">No active order for this chat</p>
          </div>
        )}
      </div>
    </div>
  );
}
