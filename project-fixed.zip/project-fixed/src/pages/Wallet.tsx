import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Wallet as WalletIcon, 
  ArrowUpRight, 
  ArrowDownLeft, 
  History, 
  ShieldCheck, 
  CreditCard, 
  QrCode, 
  Banknote, 
  Bitcoin,
  ChevronRight,
  Plus,
  Lock,
  AlertCircle,
  CheckCircle2,
  TrendingUp,
  Settings,
  HelpCircle,
  LogOut,
  Loader2
} from 'lucide-react';
import { MOCK_TRANSACTIONS } from '../constants';
import { cn } from '../lib/utils';
import { supabase } from '../lib/supabaseClient';
import { useBalance } from '../context/BalanceContext';
import { useAuth } from '../context/AuthContext';
import { Transaction } from '../types';

export default function WalletPage() {
  const { balance, refreshBalance } = useBalance();
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState<'deposit' | 'withdraw' | 'transactions'>('deposit');
  const [selectedMethod, setSelectedMethod] = useState('card');
  const [amount, setAmount] = useState('');
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isProcessing, setIsProcessing] = useState(false);
  const [statusMessage, setStatusMessage] = useState<{ type: 'success' | 'error', text: string } | null>(null);

  useEffect(() => {
    fetchTransactions();
    fetchBalance();
  }, [user]);

  useEffect(() => {
    if (statusMessage) {
      const timer = setTimeout(() => setStatusMessage(null), 5000);
      return () => clearTimeout(timer);
    }
  }, [statusMessage]);

  async function fetchBalance() {
    try {
      await refreshBalance();
    } catch (err) {
      console.error('Unexpected error:', err);
    } finally {
      setIsLoading(false);
    }
  }

  async function fetchTransactions() {
    if (!user) return;

    try {
      const { data, error } = await supabase
        .from('transactions')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });

      if (error) {
        console.error('Error fetching transactions:', error);
        setTransactions([]); // ถ้ามี Error ให้แสดงรายการว่าง แทน Mock Data
      } else if (data) {
        // Map DB fields to Transaction type
        const formattedTxs: Transaction[] = data.map((tx: any) => ({
          id: tx.id,
          type: tx.type,
          amount: tx.amount,
          method: tx.method,
          status: tx.status,
          description: tx.description,
          timestamp: new Date(tx.created_at).toLocaleString('en-US', {
            month: 'short',
            day: 'numeric',
            year: 'numeric',
            hour: '2-digit',
            minute: '2-digit',
            hour12: false
          }).replace(',', ' •')
        }));
        setTransactions(formattedTxs);
      }
    } catch (err) {
      console.error('Unexpected error fetching transactions:', err);
      setTransactions([]);
    }
  }

  async function handleDeposit() {
    if (!amount || isNaN(Number(amount)) || Number(amount) <= 0) {
      setStatusMessage({ type: 'error', text: 'กรุณากรอกจำนวนเงินที่ถูกต้อง' });
      return;
    }
    if (!user) return;

    setIsProcessing(true);
    const depositAmount = Number(amount);
    const method = DEPOSIT_METHODS.find(m => m.id === selectedMethod)?.name || 'Unknown';

    try {
      let { data, error: fetchError } = await supabase
        .from('wallets')
        .select('balance')
        .eq('user_id', user.id)
        .single();

      if (fetchError && fetchError.code === 'PGRST116') {
        // ถ้าไม่พบข้อมูล ให้สร้างกระเป๋าเงินใหม่ให้ผู้ใช้
        const { data: newData, error: insertError } = await supabase
          .from('wallets')
          .insert([{ user_id: user.id, balance: 0 }])
          .select('balance')
          .single();
        
        if (insertError) throw insertError;
        data = newData;
      } else if (fetchError) {
        console.error('Deposit fetch error:', fetchError);
        throw fetchError;
      }

      const newBalance = (data?.balance || 0) + depositAmount;

      // Update Balance
      const { error: updateError } = await supabase
        .from('wallets')
        .update({ balance: newBalance })
        .eq('user_id', user.id);

      if (updateError) {
        console.error('Deposit update error:', updateError);
        throw updateError;
      }

      // Record Transaction
      const { error: insertError } = await supabase.from('transactions').insert([{
        user_id: user.id,
        type: 'Deposit',
        amount: depositAmount,
        method: method,
        status: 'Completed',
        description: `Deposit via ${method}`
      }]);

      if (insertError) {
        console.error('Deposit insert error details:', JSON.stringify(insertError, null, 2));
        throw insertError;
      }

      refreshBalance();
      fetchTransactions();
      setStatusMessage({ type: 'success', text: `ฝากเงินสำเร็จ! ยอดใหม่คือ: ฿${newBalance.toLocaleString()}` });
      setAmount('');
    } catch (error: any) {
      console.error('Deposit full error details:', JSON.stringify(error, null, 2));
      setStatusMessage({ type: 'error', text: `เกิดข้อผิดพลาด: ${error.message || 'ตรวจสอบ Supabase'}` });
    } finally {
      setIsProcessing(false);
    }
  }

  async function handleWithdraw() {
    if (!amount || isNaN(Number(amount)) || Number(amount) <= 0) {
      setStatusMessage({ type: 'error', text: 'กรุณากรอกจำนวนเงินที่ถูกต้อง' });
      return;
    }
    if (!user) return;

    const withdrawAmount = Number(amount);
    const fee = withdrawAmount * 0.015 + 10;
    const method = withdrawMethods.find(m => m.id === selectedMethod)?.name || 'Unknown';
    
    if (balance !== null && withdrawAmount > balance) {
      setStatusMessage({ type: 'error', text: 'ยอดเงินไม่เพียงพอ' });
      return;
    }

    setIsProcessing(true);

    try {
      let { data, error: fetchError } = await supabase
        .from('wallets')
        .select('balance')
        .eq('user_id', user.id)
        .single();

      if (fetchError && fetchError.code === 'PGRST116') {
        // ถ้าไม่พบข้อมูล ให้สร้างกระเป๋าเงินใหม่ให้ผู้ใช้ (ยอดเป็น 0)
        const { data: newData, error: insertError } = await supabase
          .from('wallets')
          .insert([{ user_id: user.id, balance: 0 }])
          .select('balance')
          .single();
        
        if (insertError) throw insertError;
        data = newData;
      } else if (fetchError) {
        throw fetchError;
      }

      const newBalance = (data?.balance || 0) - withdrawAmount;

      if (newBalance < 0) {
        setStatusMessage({ type: 'error', text: 'ยอดเงินไม่เพียงพอ' });
        setIsProcessing(false);
        return;
      }

      // Update Balance
      const { error: updateError } = await supabase
        .from('wallets')
        .update({ balance: newBalance })
        .eq('user_id', user.id);

      if (updateError) throw updateError;

      // Record Transaction
      const { error: insertError } = await supabase.from('transactions').insert([{
        user_id: user.id,
        type: 'Withdraw',
        amount: withdrawAmount,
        method: method,
        status: 'Completed',
        description: `Withdraw via ${method}`
      }]);

      if (insertError) {
        console.error('Withdraw insert error details:', JSON.stringify(insertError, null, 2));
        throw insertError;
      }

      refreshBalance();
      fetchTransactions();
      setStatusMessage({ type: 'success', text: `ถอนเงินสำเร็จ! คุณจะได้รับเงิน ฿${(withdrawAmount - fee).toLocaleString()} (หักค่าธรรมเนียมแล้ว)` });
      setAmount('');
    } catch (error: any) {
      console.error('Withdrawal error details:', JSON.stringify(error, null, 2));
      setStatusMessage({ type: 'error', text: `เกิดข้อผิดพลาดในการถอนเงิน: ${error.message || 'ตรวจสอบ Supabase'}` });
    } finally {
      setIsProcessing(false);
    }
  }

  const DEPOSIT_METHODS = [
    { id: 'qr', name: 'QR PromptPay', icon: QrCode, behavior: 'scan', instruction: 'ระบบจะสร้าง QR Code ให้คุณสแกนเพื่อชำระเงิน' },
    { id: 'card', name: 'Credit/Debit', icon: CreditCard, behavior: 'input', instruction: 'กรุณากรอกข้อมูลบัตรเครดิต/เดบิตของคุณ' },
    { id: 'true', name: 'TrueMoney', icon: Banknote, behavior: 'phone', instruction: 'กรุณากรอกเบอร์โทรศัพท์ TrueMoney Wallet' },
    { id: 'crypto', name: 'Crypto', icon: Bitcoin, behavior: 'address', instruction: 'ระบบจะแสดงที่อยู่กระเป๋าเงินสำหรับโอนเหรียญ' },
  ];

  const [withdrawMethods, setWithdrawMethods] = useState([
    { id: 'bank', name: 'Chase Bank', detail: '•••• 8821', icon: Banknote },
    { id: 'paypal', name: 'PayPal Wallet', detail: 'j.bastion@neon.io', icon: WalletIcon },
  ]);
  const [isAddingMethod, setIsAddingMethod] = useState(false);
  const [newMethod, setNewMethod] = useState({ name: '', detail: '', accountName: '', accountType: 'Bank Account' });

  return (
    <div className="flex min-h-screen pt-16 bg-brand-dark">
      {/* Sidebar */}
      <div className="w-64 border-r border-white/5 bg-brand-surface/50 hidden md:flex flex-col p-6 space-y-8">
        <div className="flex items-center gap-3 px-2">
          <div className="w-10 h-10 bg-brand-primary/20 rounded-xl flex items-center justify-center">
            <ShieldCheck className="text-brand-primary w-6 h-6" />
          </div>
          <div>
            <h3 className="font-bold text-sm">Neon Bastion</h3>
            <p className="text-[10px] text-brand-primary font-bold uppercase tracking-widest">Verified Account</p>
          </div>
        </div>

        <div className="space-y-2">
          <button 
            onClick={() => setActiveTab('deposit')}
            className={cn(
              "w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all font-medium text-sm",
              (activeTab === 'deposit' || activeTab === 'withdraw') ? "bg-brand-primary/10 text-brand-primary border border-brand-primary/20" : "text-gray-400 hover:bg-white/5"
            )}
          >
            <WalletIcon className="w-5 h-5" />
            Wallet
          </button>
          <button 
            onClick={() => setActiveTab('transactions')}
            className={cn(
              "w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all font-medium text-sm",
              activeTab === 'transactions' ? "bg-brand-primary/10 text-brand-primary border border-brand-primary/20" : "text-gray-400 hover:bg-white/5"
            )}
          >
            <History className="w-5 h-5" />
            Transactions
          </button>
          <button className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-gray-400 hover:bg-white/5 transition-all font-medium text-sm">
            <Lock className="w-5 h-5" />
            Security
          </button>
        </div>

        <div className="mt-auto space-y-2">
          <button className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-gray-400 hover:bg-white/5 transition-all font-medium text-sm">
            <Settings className="w-5 h-5" />
            Settings
          </button>
          <button className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-gray-400 hover:bg-white/5 transition-all font-medium text-sm">
            <HelpCircle className="w-5 h-5" />
            Support
          </button>
          <div className="pt-4">
            <button className="w-full py-3 bg-brand-primary text-brand-dark font-bold rounded-xl hover:scale-[1.02] transition-transform">
              Deposit Funds
            </button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 p-8 overflow-y-auto">
        <div className="max-w-5xl mx-auto grid grid-cols-1 lg:grid-cols-3 gap-8">
          
          <div className="lg:col-span-2 space-y-8">
            {/* Header */}
            <div className="space-y-2">
              <h1 className="text-4xl font-display font-black">
                {activeTab === 'deposit' ? 'Deposit Funds' : activeTab === 'withdraw' ? 'Withdraw Funds' : 'Transaction History'}
              </h1>
              <p className="text-gray-400">
                {activeTab === 'deposit' ? 'Select your preferred payment method and amount to top up your balance.' : 
                 activeTab === 'withdraw' ? 'Securely transfer your earnings to your verified external accounts.' :
                 'Review your recent financial activity and trade history.'}
              </p>
            </div>

            {/* Status Message */}
            <AnimatePresence>
              {statusMessage && (
                <motion.div
                  initial={{ opacity: 0, y: -10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  className={cn(
                    "p-4 rounded-2xl border flex items-center gap-3",
                    statusMessage.type === 'success' ? "bg-green-500/10 border-green-500/20 text-green-500" : "bg-red-500/10 border-red-500/20 text-red-500"
                  )}
                >
                  {statusMessage.type === 'success' ? <CheckCircle2 className="w-5 h-5" /> : <AlertCircle className="w-5 h-5" />}
                  <p className="text-sm font-bold">{statusMessage.text}</p>
                </motion.div>
              )}
            </AnimatePresence>

            {/* Deposit/Withdraw UI */}
            {(activeTab === 'deposit' || activeTab === 'withdraw') && (
              <div className="space-y-8">
                {/* Modal for adding new method */}
                <AnimatePresence>
                  {isAddingMethod && (
                    <motion.div
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      exit={{ opacity: 0 }}
                      className="fixed inset-0 z-50 bg-brand-dark/80 backdrop-blur-sm flex items-center justify-center p-4"
                    >
                      <motion.div
                        initial={{ scale: 0.9 }}
                        animate={{ scale: 1 }}
                        exit={{ scale: 0.9 }}
                        className="bg-brand-surface border border-white/10 p-8 rounded-3xl w-full max-w-md space-y-6"
                      >
                        <h3 className="text-xl font-display font-black">Add New Method</h3>
                        <div className="space-y-4">
                          <input 
                            type="text"
                            placeholder="Method Name (e.g. Bank Name)"
                            className="w-full bg-brand-dark border border-white/5 rounded-xl py-3 px-4"
                            value={newMethod.name}
                            onChange={(e) => setNewMethod({ ...newMethod, name: e.target.value })}
                          />
                          <select
                            className="w-full bg-brand-dark border border-white/5 rounded-xl py-3 px-4 text-gray-400"
                            value={newMethod.accountType}
                            onChange={(e) => setNewMethod({ ...newMethod, accountType: e.target.value })}
                          >
                            <option value="Bank Account">Bank Account</option>
                            <option value="TrueMoney Wallet">TrueMoney Wallet</option>
                            <option value="Crypto Wallet">Crypto Wallet</option>
                            <option value="Other">Other</option>
                          </select>
                          <input 
                            type="text"
                            placeholder="Account Name (e.g. John Doe)"
                            className="w-full bg-brand-dark border border-white/5 rounded-xl py-3 px-4"
                            value={newMethod.accountName}
                            onChange={(e) => setNewMethod({ ...newMethod, accountName: e.target.value })}
                          />
                          <input 
                            type="text"
                            placeholder={
                              newMethod.accountType === 'Bank Account' ? 'Account Number' :
                              newMethod.accountType === 'TrueMoney Wallet' ? 'Phone Number' :
                              newMethod.accountType === 'Crypto Wallet' ? 'Wallet Address' :
                              'Account Detail'
                            }
                            className="w-full bg-brand-dark border border-white/5 rounded-xl py-3 px-4"
                            value={newMethod.detail}
                            onChange={(e) => setNewMethod({ ...newMethod, detail: e.target.value })}
                          />
                          <p className="text-[10px] text-brand-primary font-bold">
                            * คำเตือน: ชื่อบัญชีต้องตรงกับชื่อเจ้าของบัญชีที่ระบุไว้ เพื่อป้องกันข้อผิดพลาดในการโอนเงิน
                          </p>
                        </div>
                        <div className="flex gap-4">
                          <button onClick={() => setIsAddingMethod(false)} className="flex-1 py-3 bg-white/5 rounded-xl font-bold hover:bg-white/10">Cancel</button>
                          <button 
                            onClick={() => {
                              setWithdrawMethods([...withdrawMethods, { 
                                id: Date.now().toString(), 
                                name: newMethod.name, 
                                detail: `${newMethod.accountName} • ${newMethod.accountType} • ${newMethod.detail}`, 
                                icon: WalletIcon 
                              }]);
                              setIsAddingMethod(false);
                              setNewMethod({ name: '', detail: '', accountName: '', accountType: 'Bank Account' });
                            }}
                            className="flex-1 py-3 bg-brand-primary text-brand-dark font-bold rounded-xl hover:scale-[1.02]"
                          >
                            Add
                          </button>
                        </div>
                      </motion.div>
                    </motion.div>
                  )}
                </AnimatePresence>

                {/* Select Method */}
                <div className="space-y-4">
                  <h3 className="text-xs font-bold text-gray-500 uppercase tracking-widest">
                    {activeTab === 'deposit' ? '01. Select Method' : 'Select Withdrawal Method'}
                  </h3>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                    {(activeTab === 'deposit' ? DEPOSIT_METHODS : withdrawMethods).map((method) => (
                      <button
                        key={method.id}
                        onClick={() => setSelectedMethod(method.id)}
                        className={cn(
                          "relative p-6 rounded-2xl border transition-all flex flex-col items-center gap-3 text-center",
                          selectedMethod === method.id 
                            ? "bg-brand-primary/5 border-brand-primary/50 ring-1 ring-brand-primary/50" 
                            : "bg-brand-surface border-white/5 hover:border-white/10"
                        )}
                      >
                        <div className={cn(
                          "w-12 h-12 rounded-xl flex items-center justify-center",
                          selectedMethod === method.id ? "bg-brand-primary/20 text-brand-primary" : "bg-white/5 text-gray-500"
                        )}>
                          <method.icon className="w-6 h-6" />
                        </div>
                        <div>
                          <p className="text-sm font-bold">{method.name}</p>
                          {'detail' in method && <p className="text-[10px] text-gray-500">{method.detail}</p>}
                        </div>
                        {selectedMethod === method.id && (
                          <div className="absolute top-3 right-3 w-4 h-4 rounded-full bg-brand-primary flex items-center justify-center">
                            <div className="w-1.5 h-1.5 rounded-full bg-brand-dark" />
                          </div>
                        )}
                      </button>
                    ))}
                    {activeTab === 'withdraw' && (
                      <button 
                        onClick={() => setIsAddingMethod(true)}
                        className="p-6 rounded-2xl border border-dashed border-white/10 hover:border-white/20 transition-all flex flex-col items-center justify-center gap-2 text-gray-500"
                      >
                        <Plus className="w-6 h-6" />
                        <span className="text-xs font-bold uppercase tracking-wider">Add New</span>
                      </button>
                    )}
                  </div>
                  {activeTab === 'deposit' && (
                    <div className="space-y-4">
                      <div className="p-4 bg-brand-surface border border-white/5 rounded-2xl text-sm text-gray-400 flex items-center gap-3">
                        <div className="w-2 h-2 rounded-full bg-brand-primary animate-pulse" />
                        {DEPOSIT_METHODS.find(m => m.id === selectedMethod)?.instruction}
                      </div>
                      {selectedMethod !== 'qr' && (
                        <input 
                          type="text"
                          placeholder={selectedMethod === 'card' ? 'กรอกเลขบัตร 16 หลัก' : selectedMethod === 'true' ? 'กรอกเบอร์โทรศัพท์' : 'กรอกที่อยู่กระเป๋าเงิน'}
                          className="w-full bg-brand-surface border border-white/5 rounded-2xl py-5 px-4 focus:outline-none focus:ring-2 focus:ring-brand-primary/50 transition-all text-lg font-medium"
                        />
                      )}
                    </div>
                  )}
                </div>

                {/* Amount Selection */}
                <div className="space-y-4">
                  <h3 className="text-xs font-bold text-gray-500 uppercase tracking-widest">
                    {activeTab === 'deposit' ? '02. Deposit Amount' : 'Amount to Withdraw'}
                  </h3>
                  <div className="grid grid-cols-4 gap-4">
                    {['100', '500', '1000', '5000'].map((val) => (
                      <button
                        key={val}
                        onClick={() => setAmount(val)}
                        className={cn(
                          "py-4 rounded-xl border transition-all font-display font-black text-lg",
                          amount === val ? "bg-brand-secondary text-white border-brand-secondary shadow-[0_0_20px_rgba(0,212,255,0.3)]" : "bg-brand-surface border-white/5 hover:border-white/10"
                        )}
                      >
                        ฿{val}
                      </button>
                    ))}
                  </div>
                  
                  <div className="relative">
                    <div className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500 font-bold">฿</div>
                    <input 
                      type="number"
                      placeholder="Enter custom amount..."
                      className="w-full bg-brand-surface border border-white/5 rounded-2xl py-5 pl-10 pr-16 focus:outline-none focus:ring-2 focus:ring-brand-primary/50 transition-all text-lg font-medium"
                      value={amount}
                      onChange={(e) => setAmount(e.target.value)}
                    />
                    {activeTab === 'withdraw' && balance !== null && (
                      <button
                        type="button"
                        onClick={() => setAmount(balance.toString())}
                        className="absolute right-4 top-1/2 -translate-y-1/2 text-xs font-bold text-brand-primary hover:text-brand-primary/80 transition-colors"
                      >
                        MAX
                      </button>
                    )}
                  </div>
                </div>

                {/* Bonus / Fees */}
                {activeTab === 'withdraw' && (
                  <div className="space-y-4">
                    <div className="p-6 rounded-2xl bg-brand-surface border border-white/5 flex items-center gap-4">
                      <div className="w-10 h-10 bg-brand-primary/10 rounded-xl flex items-center justify-center">
                        <AlertCircle className="text-brand-primary w-6 h-6" />
                      </div>
                      <div className="flex-1">
                        <h4 className="text-xs font-bold uppercase tracking-wider text-gray-400">Fees & Processing Time</h4>
                        <p className="text-sm text-gray-500">
                          Fee: <span className="text-white font-bold">1.5% + 10 THB</span> • Estimated Time: <span className="text-white font-bold">1-3 Business Days</span>
                        </p>
                      </div>
                    </div>

                    {amount && Number(amount) > 0 && (
                      <div className="p-6 rounded-2xl bg-white/5 border border-white/10 space-y-3">
                        <div className="flex justify-between text-sm">
                          <span className="text-gray-400">Withdrawal Amount</span>
                          <span className="font-bold">฿{Number(amount).toLocaleString()}</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span className="text-gray-400">Processing Fee (1.5%)</span>
                          <span className="text-red-400">-฿{(Number(amount) * 0.015).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span className="text-gray-400">Fixed Fee</span>
                          <span className="text-red-400">-฿10.00</span>
                        </div>
                        <div className="pt-3 border-t border-white/10 flex justify-between items-center">
                          <span className="font-bold text-gray-300">You will receive</span>
                          <span className="text-2xl font-display font-black text-brand-primary">
                            ฿{Math.max(0, Number(amount) - (Number(amount) * 0.015 + 10)).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                          </span>
                        </div>
                      </div>
                    )}
                  </div>
                )}

                <button 
                  onClick={activeTab === 'deposit' ? handleDeposit : handleWithdraw}
                  disabled={isProcessing || !amount}
                  className="w-full py-5 bg-brand-secondary text-white font-display font-black text-xl rounded-2xl hover:scale-[1.02] active:scale-[0.98] transition-all shadow-[0_0_30px_rgba(0,212,255,0.2)] disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-3"
                >
                  {isProcessing && <Loader2 className="w-6 h-6 animate-spin" />}
                  {activeTab === 'deposit' ? 'Complete Deposit' : 'Authorize Transfer'}
                </button>
              </div>
            )}

            {/* Transactions List */}
            {activeTab === 'transactions' && (
              <div className="space-y-4">
                {transactions.length > 0 ? (
                  transactions.map((tx) => (
                    <div key={tx.id} className="p-4 bg-brand-surface border border-white/5 rounded-2xl flex items-center justify-between hover:border-white/10 transition-all">
                      <div className="flex items-center gap-4">
                        <div className={cn(
                          "w-12 h-12 rounded-xl flex items-center justify-center",
                          tx.type === 'Deposit' ? "bg-green-500/10 text-green-500" : 
                          tx.type === 'Withdraw' ? "bg-brand-primary/10 text-brand-primary" : "bg-brand-secondary/10 text-brand-secondary"
                        )}>
                          {tx.type === 'Deposit' ? <ArrowDownLeft className="w-6 h-6" /> : <ArrowUpRight className="w-6 h-6" />}
                        </div>
                        <div>
                          <h4 className="font-bold text-sm">{tx.description}</h4>
                          <p className="text-xs text-gray-500">{tx.timestamp}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className={cn(
                          "text-lg font-display font-black",
                          tx.type === 'Deposit' ? "text-green-500" : "text-white"
                        )}>
                          {tx.type === 'Deposit' ? '+' : '-'}฿{tx.amount.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                        </div>
                        <div className={cn(
                          "text-[10px] font-bold uppercase tracking-widest",
                          tx.status === 'Completed' ? "text-green-500" : 
                          tx.status === 'Pending' ? "text-brand-primary" : "text-red-500"
                        )}>
                          {tx.status}
                        </div>
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="text-center py-12 space-y-4">
                    <div className="w-16 h-16 bg-white/5 rounded-full flex items-center justify-center mx-auto">
                      <History className="w-8 h-8 text-gray-500" />
                    </div>
                    <p className="text-gray-500 font-medium">No transactions found.</p>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Right Sidebar - Balance Info */}
          <div className="space-y-8">
            <div className="p-8 rounded-3xl bg-brand-surface border border-white/5 space-y-6">
              <div className="flex items-center justify-between">
                <h3 className="text-xs font-bold text-gray-500 uppercase tracking-widest">Current Balance</h3>
                <button className="p-1 hover:bg-white/5 rounded-lg text-gray-500">
                  <Plus className="w-4 h-4" />
                </button>
              </div>
              <div className="space-y-1">
                <div className="text-5xl font-display font-black">
                  {isLoading ? (
                    <div className="h-12 w-32 bg-white/5 animate-pulse rounded-lg" />
                  ) : (
                    `฿${(balance || 0).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`
                  )}
                </div>
                <div className="flex items-center gap-2 text-green-500 text-sm font-bold">
                  <TrendingUp className="w-4 h-4" />
                  +12.4% from last month
                </div>
              </div>
              
              <div className="pt-6 border-t border-white/5 flex gap-4">
                <button 
                  onClick={() => setActiveTab('deposit')}
                  className="flex-1 py-3 bg-white/5 border border-white/10 rounded-xl text-xs font-bold uppercase tracking-wider hover:bg-white/10 transition-all"
                >
                  Deposit
                </button>
                <button 
                  onClick={() => setActiveTab('withdraw')}
                  className="flex-1 py-3 bg-white/5 border border-white/10 rounded-xl text-xs font-bold uppercase tracking-wider hover:bg-white/10 transition-all"
                >
                  Withdraw
                </button>
              </div>
            </div>

            <div className="p-6 rounded-3xl bg-brand-surface border border-white/5 space-y-4">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 bg-brand-primary/10 rounded-lg flex items-center justify-center">
                  <Lock className="text-brand-primary w-4 h-4" />
                </div>
                <h4 className="font-bold text-sm">Secure Transaction</h4>
              </div>
              <p className="text-xs text-gray-500 leading-relaxed">
                Your funds are protected by our proprietary Escrow protocol. Credits are released only after verification.
              </p>
              <div className="flex gap-2">
                <div className="px-2 py-1 bg-white/5 rounded text-[8px] font-bold text-gray-400 uppercase">PCI-DSS Compliant</div>
                <div className="px-2 py-1 bg-white/5 rounded text-[8px] font-bold text-gray-400 uppercase">Jakub Escrow®</div>
              </div>
            </div>

            <div className="relative rounded-3xl overflow-hidden aspect-video bg-gradient-to-br from-brand-primary/20 to-brand-secondary/20 border border-white/10 p-6 flex flex-col justify-end">
              <div className="absolute top-0 left-0 w-full h-full bg-[url('https://picsum.photos/seed/shield/800/400')] opacity-20 mix-blend-overlay" />
              <div className="relative space-y-2">
                <h4 className="font-display font-black text-lg">Security Shield</h4>
                <p className="text-[10px] text-gray-400 leading-relaxed">
                  All withdrawals are held in escrow for 24 hours to ensure account integrity.
                </p>
              </div>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
}
