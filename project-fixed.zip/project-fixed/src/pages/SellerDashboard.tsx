import React, { useState, useEffect } from 'react';
import { 
  LayoutDashboard, 
  Package, 
  BarChart3, 
  Wallet, 
  Settings, 
  HelpCircle, 
  Plus, 
  Search, 
  Bell, 
  TrendingUp, 
  Lock, 
  Info,
  Zap,
  MessageSquare,
  ShieldCheck,
  ArrowLeft
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  Cell
} from 'recharts';
import { 
  MOCK_SELLER_STATS, 
  MOCK_REVENUE_DATA, 
  MOCK_ACTIVE_LISTINGS, 
  MOCK_ESCROW_TRANSACTIONS 
} from '../constants';
import { cn } from '../lib/utils';
import { supabase } from '../lib/supabaseClient';
import { useAuth } from '../context/AuthContext';

export default function SellerDashboard() {
  const { user } = useAuth();
  const [totalEarnings, setTotalEarnings] = useState(0);

  useEffect(() => {
    const fetchEarnings = async () => {
      if (!user) return;

      const { data, error } = await supabase
        .from('transactions')
        .select('amount')
        .eq('user_id', user.id)
        .eq('type', 'Deposit')
        .eq('status', 'Completed');

      if (error) {
        console.error('Error fetching earnings:', error);
        return;
      }

      if (data) {
        const total = data.reduce((sum, tx) => sum + tx.amount, 0);
        setTotalEarnings(total);
      }
    };

    fetchEarnings();
  }, [user]);

  return (
    <div className="flex min-h-screen pt-16 bg-brand-dark">
      {/* Sidebar */}
      <div className="w-64 border-r border-white/5 bg-brand-surface/50 hidden lg:flex flex-col p-6 space-y-8">
        <Link to="/" className="flex items-center gap-3 px-2 group">
          <div className="w-10 h-10 bg-brand-primary/20 rounded-xl flex items-center justify-center group-hover:bg-brand-primary/30 transition-colors">
            <ShieldCheck className="text-brand-primary w-6 h-6" />
          </div>
          <div>
            <h3 className="font-bold text-sm">Jakub</h3>
            <p className="text-[10px] text-gray-500 font-bold uppercase tracking-widest">Verified Seller</p>
          </div>
        </Link>

        <nav className="space-y-2">
          <NavItem icon={LayoutDashboard} label="Dashboard" to="/seller-hub" active />
          <NavItem icon={Package} label="Inventory" to="/inventory" />
          <NavItem icon={BarChart3} label="Sales" to="/sell" />
          <NavItem icon={BarChart3} label="History" to="/sales-history" />
          <NavItem icon={Wallet} label="Payouts" to="/wallet" />
          <div className="pt-4 mt-4 border-t border-white/5">
            <Link to="/" className="w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all font-medium text-sm text-gray-400 hover:bg-white/5 hover:text-white">
              <ArrowLeft className="w-5 h-5" />
              Exit Seller Hub
            </Link>
          </div>
        </nav>

        <div className="pt-4">
          <Link to="/sell" className="w-full py-3 bg-brand-secondary text-white font-bold rounded-xl hover:scale-[1.02] transition-transform flex items-center justify-center gap-2 shadow-[0_0_20px_rgba(0,212,255,0.2)]">
            <Plus className="w-4 h-4" />
            List New Asset
          </Link>
        </div>

        <div className="mt-auto space-y-2">
          <NavItem icon={Settings} label="Settings" />
          <NavItem icon={HelpCircle} label="Support" />
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 p-8 overflow-y-auto">
        <div className="max-w-7xl mx-auto space-y-8">
          
          {/* Top Bar */}
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="flex items-center gap-4">
              <Link to="/" className="p-2 hover:bg-white/5 rounded-xl text-gray-400 transition-colors">
                <ArrowLeft className="w-5 h-5" />
              </Link>
              <h1 className="text-2xl font-display font-black">Seller Hub</h1>
            </div>
            <div className="flex items-center gap-4">
              <div className="relative hidden md:block">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
                <input 
                  type="text" 
                  placeholder="Search orders..."
                  className="bg-white/5 border border-white/10 rounded-xl py-2 pl-10 pr-4 text-sm focus:outline-none focus:ring-1 focus:ring-brand-primary/50 w-64"
                />
              </div>
              <button className="px-4 py-2 bg-white/5 border border-white/10 rounded-xl text-xs font-bold hover:bg-white/10 transition-colors">
                Withdraw Funds
              </button>
              <button className="p-2 hover:bg-white/5 rounded-xl text-gray-400 relative">
                <Bell className="w-5 h-5" />
                <span className="absolute top-2 right-2 w-2 h-2 bg-brand-primary rounded-full border-2 border-brand-dark" />
              </button>
              <div className="flex items-center gap-3 pl-4 border-l border-white/10">
                <div className="text-right hidden sm:block">
                  <p className="text-xs font-bold">Jakub</p>
                  <p className="text-[10px] text-brand-primary font-bold uppercase tracking-widest">Top Tier</p>
                </div>
                <img src="https://api.dicebear.com/7.x/avataaars/svg?seed=Jakub" className="w-10 h-10 rounded-xl bg-white/5" alt="Avatar" />
              </div>
            </div>
          </div>

          {/* Stats Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Total Earnings Card */}
            <div className="lg:col-span-2 p-8 rounded-[32px] bg-brand-secondary/80 text-white relative overflow-hidden group">
              <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 rounded-full blur-[80px] -mr-32 -mt-32" />
              <div className="relative space-y-6">
                <div>
                  <p className="text-xs font-bold uppercase tracking-widest opacity-60">Total Earnings</p>
                  <h2 className="text-6xl font-display font-black mt-2">${totalEarnings.toLocaleString()}</h2>
                  <div className="flex items-center gap-2 text-white/80 text-sm font-bold mt-2">
                    <TrendingUp className="w-4 h-4" />
                    +{MOCK_SELLER_STATS.earningsGrowth}% from last month
                  </div>
                </div>
                <div className="flex gap-4">
                  <button className="px-6 py-3 bg-white text-brand-dark font-bold rounded-xl hover:scale-105 transition-transform">
                    Withdraw Funds
                  </button>
                  <button className="px-6 py-3 bg-white/10 backdrop-blur-md border border-white/20 font-bold rounded-xl hover:bg-white/20 transition-colors">
                    Transaction History
                  </button>
                </div>
              </div>
            </div>

            {/* Pending Payouts Card */}
            <div className="p-8 rounded-[32px] bg-brand-surface border border-white/5 flex flex-col justify-between">
              <div className="flex justify-between items-start">
                <div className="w-12 h-12 bg-brand-primary/10 rounded-2xl flex items-center justify-center">
                  <Lock className="text-brand-primary w-6 h-6" />
                </div>
                <span className="text-[10px] font-bold text-gray-500 uppercase tracking-widest">Escrow Hold</span>
              </div>
              <div>
                <p className="text-xs font-bold text-gray-500 uppercase tracking-widest">Pending Payouts</p>
                <h3 className="text-4xl font-display font-black mt-1">${MOCK_SELLER_STATS.pendingPayouts.toLocaleString()}</h3>
              </div>
              <div className="p-3 bg-white/5 rounded-xl flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="text-[10px] text-gray-400">Next release in:</span>
                  <span className="text-xs font-bold text-brand-primary">{MOCK_SELLER_STATS.nextReleaseTime}</span>
                </div>
                <Info className="w-4 h-4 text-gray-600" />
              </div>
            </div>
          </div>

          {/* Revenue Chart & Quick Actions */}
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
            {/* Chart */}
            <div className="lg:col-span-3 p-8 rounded-[32px] bg-brand-surface border border-white/5 space-y-6">
              <div className="flex items-center justify-between">
                <h3 className="font-bold">Daily Sales Revenue</h3>
                <div className="flex bg-white/5 rounded-lg p-1">
                  <button className="px-3 py-1 text-[10px] font-bold uppercase tracking-widest bg-brand-primary/20 text-brand-primary rounded-md">14D</button>
                  <button className="px-3 py-1 text-[10px] font-bold uppercase tracking-widest text-gray-500 hover:text-gray-300">30D</button>
                </div>
              </div>
              <div className="h-[300px] w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={MOCK_REVENUE_DATA}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#ffffff05" vertical={false} />
                    <XAxis 
                      dataKey="date" 
                      axisLine={false} 
                      tickLine={false} 
                      tick={{ fill: '#6b7280', fontSize: 10, fontWeight: 600 }}
                      dy={10}
                    />
                    <Tooltip 
                      cursor={{ fill: '#ffffff05' }}
                      contentStyle={{ backgroundColor: '#111111', border: '1px solid #ffffff10', borderRadius: '12px' }}
                    />
                    <Bar dataKey="revenue" radius={[4, 4, 0, 0]}>
                      {MOCK_REVENUE_DATA.map((entry, index) => (
                        <Cell 
                          key={`cell-${index}`} 
                          fill={index === MOCK_REVENUE_DATA.length - 1 ? '#00d4ff' : '#00d4ff30'} 
                          className="hover:fill-brand-primary transition-colors"
                        />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Quick Actions */}
            <div className="space-y-6">
              <div className="p-8 rounded-[32px] bg-brand-surface border border-white/5 space-y-6">
                <h3 className="font-bold text-sm uppercase tracking-widest text-gray-500">Quick Actions</h3>
                <div className="space-y-3">
                  <QuickAction icon={Plus} label="List New Asset" />
                  <QuickAction icon={Zap} label="Promote Listing" />
                  <QuickAction icon={MessageSquare} label="Contact Support" />
                </div>
              </div>

              <div className="p-8 rounded-[32px] bg-gradient-to-br from-brand-primary/10 to-brand-secondary/10 border border-brand-primary/20 relative overflow-hidden">
                <div className="absolute top-2 right-2">
                  <ShieldCheck className="text-brand-primary w-5 h-5" />
                </div>
                <h4 className="text-[10px] font-bold text-brand-primary uppercase tracking-widest mb-2">Pro Seller</h4>
                <p className="text-xs text-gray-400 leading-relaxed">
                  Your premium status will renew in 12 days. Maintain 98% positive feedback to keep benefits.
                </p>
              </div>
            </div>
          </div>

          {/* Active Listings & Escrow */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Active Listings */}
            <div className="lg:col-span-2 p-8 rounded-[32px] bg-brand-surface border border-white/5 space-y-6">
              <div className="flex items-center justify-between">
                <h3 className="font-bold">Active Listings</h3>
                <button className="text-xs font-bold text-brand-primary hover:underline">View All</button>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="text-[10px] font-bold text-gray-500 uppercase tracking-widest border-b border-white/5">
                      <th className="text-left pb-4">Asset Name</th>
                      <th className="text-left pb-4">Game</th>
                      <th className="text-left pb-4">Price</th>
                      <th className="text-left pb-4">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-white/5">
                    {MOCK_ACTIVE_LISTINGS.map((listing) => (
                      <tr key={listing.id} className="group hover:bg-white/5 transition-colors">
                        <td className="py-4">
                          <div className="flex items-center gap-3">
                            <img src={listing.image} className="w-10 h-10 rounded-lg bg-white/5" alt="" />
                            <div>
                              <p className="text-sm font-bold">{listing.title}</p>
                              <p className="text-[10px] text-gray-500 uppercase tracking-widest">Legendary Skin</p>
                            </div>
                          </div>
                        </td>
                        <td className="py-4 text-sm text-gray-400">{listing.game}</td>
                        <td className="py-4 font-display font-black text-brand-primary">${listing.price.toFixed(2)}</td>
                        <td className="py-4">
                          <div className={cn(
                            "inline-flex px-2 py-1 rounded-md text-[10px] font-bold uppercase tracking-wider",
                            listing.status === 'Active' ? "bg-brand-primary/10 text-brand-primary" :
                            listing.status === 'Sold' ? "bg-brand-secondary/10 text-brand-secondary" :
                            "bg-purple-500/10 text-purple-400"
                          )}>
                            {listing.status}
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Recent Sales & Escrow */}
            <div className="p-8 rounded-[32px] bg-brand-surface border border-white/5 space-y-6">
              <div className="flex items-center justify-between">
                <h3 className="font-bold">Recent Sales & Escrow</h3>
                <div className="flex items-center gap-1.5">
                  <div className="w-2 h-2 rounded-full bg-brand-primary" />
                  <span className="text-[10px] font-bold text-gray-500 uppercase tracking-widest">4 Active Escrows</span>
                </div>
              </div>
              <div className="space-y-4">
                {MOCK_ESCROW_TRANSACTIONS.map((tx) => (
                  <div key={tx.id} className="p-5 bg-brand-dark/50 border border-white/5 rounded-2xl space-y-4">
                    <div className="flex justify-between items-start">
                      <div>
                        <p className="text-xs font-bold">Buyer: {tx.buyer}</p>
                        <p className="text-[10px] text-gray-500 mt-1">Item: {tx.item}</p>
                      </div>
                      <span className="font-display font-black text-brand-primary">${tx.price.toFixed(2)}</span>
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between items-center text-[10px] font-bold uppercase tracking-widest">
                        <span className={cn(
                          tx.status === 'Asset Delivered' ? "text-brand-secondary" : 
                          tx.status === 'Awaiting Confirmation' ? "text-purple-400" : "text-brand-primary"
                        )}>{tx.status}</span>
                        <span className="text-gray-500">Step {tx.step} of {tx.totalSteps}</span>
                      </div>
                      <div className="h-1 bg-white/5 rounded-full overflow-hidden">
                        <div 
                          className={cn(
                            "h-full transition-all duration-500",
                            tx.status === 'Asset Delivered' ? "bg-brand-secondary" : 
                            tx.status === 'Awaiting Confirmation' ? "bg-purple-400" : "bg-brand-primary"
                          )}
                          style={{ width: `${(tx.step / tx.totalSteps) * 100}%` }}
                        />
                      </div>
                    </div>
                    <p className="text-[10px] text-gray-600 italic">
                      {tx.status === 'Asset Delivered' ? 'Awaiting buyer confirmation to release funds.' : 
                       tx.status === 'Awaiting Confirmation' ? 'Verify trade completion within 24 hours.' :
                       'Payout initiated. Funds will appear in dashboard shortly.'}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
}

function NavItem({ icon: Icon, label, to = "#", active = false }: { icon: any, label: string, to?: string, active?: boolean }) {
  return (
    <Link to={to} className={cn(
      "w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all font-medium text-sm",
      active ? "bg-brand-primary/10 text-brand-primary border border-brand-primary/20" : "text-gray-400 hover:bg-white/5"
    )}>
      <Icon className="w-5 h-5" />
      {label}
    </Link>
  );
}

function QuickAction({ icon: Icon, label }: { icon: any, label: string }) {
  return (
    <button className="w-full flex items-center gap-3 p-4 bg-white/5 border border-white/10 rounded-2xl hover:bg-white/10 transition-all group">
      <div className="w-8 h-8 bg-brand-primary/10 rounded-lg flex items-center justify-center group-hover:bg-brand-primary/20 transition-colors">
        <Icon className="w-4 h-4 text-brand-primary" />
      </div>
      <span className="text-xs font-bold text-gray-300">{label}</span>
    </button>
  );
}
