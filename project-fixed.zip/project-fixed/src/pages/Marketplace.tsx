import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Search, Filter, ShoppingCart, Star, ChevronRight, X, ShieldCheck, AlertCircle } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { Listing } from '../types';
import { CATEGORIES } from '../constants';
import { cn } from '../lib/utils';
import { useBalance } from '../context/BalanceContext';
import { useAuth } from '../context/AuthContext';
import { supabase } from '../lib/supabaseClient';

interface ListingCardProps {
  listing: Listing;
  onBuy: (listing: Listing) => void;
  key?: string;
}

const ListingCard = ({ listing, onBuy }: ListingCardProps) => {
  return (
    <motion.div
      whileHover={{ y: -8 }}
      className="group bg-brand-surface border border-white/5 rounded-2xl overflow-hidden hover:border-brand-primary/30 transition-all"
    >
      <div className="relative aspect-[4/3] overflow-hidden">
        <img 
          src={listing.image} 
          alt={listing.title}
          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
          referrerPolicy="no-referrer"
        />
        <div className="absolute top-3 left-3 px-2 py-1 bg-black/60 backdrop-blur-md rounded-lg text-[10px] font-bold uppercase tracking-wider">
          {listing.game}
        </div>
        <div className="absolute top-3 right-3 p-2 bg-brand-primary text-brand-dark rounded-lg shadow-lg">
          <ShoppingCart className="w-4 h-4" />
        </div>
      </div>
      
      <div className="p-5 space-y-4">
        <div className="space-y-1">
          <div className="text-xs text-brand-primary font-bold uppercase tracking-widest">{listing.category}</div>
          <h3 className="text-lg font-display font-bold leading-tight line-clamp-2 group-hover:text-brand-primary transition-colors">
            {listing.title}
          </h3>
        </div>

        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 bg-white/10 rounded-full" />
            <span className="text-sm text-gray-400">{listing.seller}</span>
          </div>
          <div className="flex items-center gap-1 text-yellow-500">
            <Star className="w-3 h-3 fill-current" />
            <span className="text-xs font-bold">{listing.rating}</span>
          </div>
        </div>

        <div className="pt-4 border-t border-white/5 flex items-center justify-between">
          <div className="text-2xl font-display font-black">${listing.price}</div>
          <button 
            onClick={() => onBuy(listing)}
            className="flex items-center gap-1 text-sm font-bold text-brand-primary group-hover:gap-2 transition-all"
          >
            Buy Now <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </motion.div>
  );
};

export default function MarketplacePage() {
  const [listings, setListings] = useState<Listing[]>([]);
  const [activeCategory, setActiveCategory] = useState('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedListing, setSelectedListing] = useState<Listing | null>(null);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchProducts = async () => {
      const { data, error } = await supabase
        .from('products')
        .select('*');

      if (error) {
        console.error('Error fetching products:', error);
        return;
      }

      if (data) {
        const mappedListings: Listing[] = data.map((product: any) => ({
          id: product.id,
          title: product.name,
          game: 'Unknown Game', // Default
          price: Number(product.price),
          seller: 'Unknown Seller', // Default
          rating: 0, // Default
          image: product.image_url || 'https://picsum.photos/seed/product/400/300',
          category: 'Item', // Default
          description: product.description,
          status: product.status === 'available' ? 'Available' : 'Sold',
        }));
        setListings(mappedListings);
      }
    };

    fetchProducts();
  }, []);

  const filteredListings = listings.filter(listing => {
    // Map category button names to listing category values
    const categoryMap: Record<string, string[]> = {
      'All': [],
      'Accounts': ['Account'],
      'Items': ['Item'],
      'Boosting': ['Service'],
      'Currency': ['Item'], // fallback, adjust as needed
    };
    const matchesCategory = activeCategory === 'All' || 
      (categoryMap[activeCategory] ?? []).includes(listing.category);
    const matchesSearch = listing.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          listing.game.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const { balance, refreshBalance } = useBalance();
  const { user } = useAuth(); // ต้อง import useAuth

  const [isPurchasing, setIsPurchasing] = useState(false);

  const handleConfirmPurchase = async () => {
    if (!selectedListing || !user || balance === null || balance < selectedListing.price) {
      alert('เงินไม่พอหรือเกิดข้อผิดพลาด');
      return;
    }

    setIsPurchasing(true); // เริ่ม loading

    // 1. บันทึก escrow
    const { error: escrowError } = await supabase
      .from('escrow_transactions')
      .insert([{
        product_id: selectedListing.id,
        buyer_id: user.id,
        amount: selectedListing.price,
        status: 'pending'
      }]);

    if (escrowError) {
      console.error('Escrow error:', escrowError);
      alert('เกิดข้อผิดพลาดในการสร้างรายการซื้อ');
      setIsPurchasing(false);
      return;
    }

    // 2. อัปเดตสถานะสินค้าเป็น sold
    const { error: productError } = await supabase
      .from('products')
      .update({ status: 'sold' })
      .eq('id', selectedListing.id);

    if (productError) {
      console.error('Product update error:', productError);
      alert('เกิดข้อผิดพลาดในการอัปเดตสถานะสินค้า');
      setIsPurchasing(false);
      return;
    }

    // 3. หักเงินจาก Wallet
    const { error: walletError } = await supabase
      .from('wallets')
      .update({ balance: balance - selectedListing.price })
      .eq('user_id', user.id);

    if (walletError) {
      console.error('Wallet error:', walletError);
      alert('เกิดข้อผิดพลาดในการหักเงิน');
      setIsPurchasing(false);
      return;
    }

    await refreshBalance();
    alert('ซื้อสินค้าสำเร็จ!');
    setIsPurchasing(false);
    setSelectedListing(null);
    navigate('/messages');
  };

  return (
    <div className="min-h-screen pt-24 pb-20 px-4">
      <div className="max-w-7xl mx-auto space-y-12">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
          <div className="space-y-2">
            <h1 className="text-4xl font-display font-black">Marketplace</h1>
            <p className="text-gray-400">Browse thousands of gaming assets from verified sellers.</p>
          </div>
          <div className="relative w-full md:w-96">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
            <input
              type="text"
              placeholder="Search listings..."
              className="w-full bg-white/5 border border-white/10 rounded-xl py-3 pl-12 pr-4 focus:outline-none focus:ring-2 focus:ring-brand-primary/50 transition-all"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
        </div>

        <div className="flex items-center gap-4 overflow-x-auto pb-4 no-scrollbar">
          {CATEGORIES.map((cat) => (
            <button
              key={cat.name}
              onClick={() => setActiveCategory(cat.name)}
              className={cn(
                "flex items-center gap-2 px-6 py-3 rounded-xl border transition-all whitespace-nowrap font-medium",
                activeCategory === cat.name 
                  ? "bg-brand-primary border-brand-primary text-brand-dark shadow-[0_0_20px_rgba(0,255,136,0.3)]" 
                  : "bg-white/5 border-white/10 text-gray-400 hover:border-white/20"
              )}
            >
              <cat.icon className="w-4 h-4" />
              {cat.name}
            </button>
          ))}
          <button className="ml-auto p-3 bg-white/5 border border-white/10 rounded-xl hover:bg-white/10 transition-colors">
            <Filter className="w-5 h-5" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {filteredListings.length > 0 ? (
            filteredListings.map((listing) => (
              <ListingCard 
                key={listing.id} 
                listing={listing} 
                onBuy={(l) => setSelectedListing(l)}
              />
            ))
          ) : (
            <div className="col-span-full py-20 text-center space-y-4">
              <div className="text-gray-500 text-lg">No listings found matching your criteria.</div>
              <button 
                onClick={() => { setActiveCategory('All'); setSearchQuery(''); }}
                className="text-brand-primary font-bold hover:underline"
              >
                Clear all filters
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Purchase Confirmation Modal */}
      <AnimatePresence>
        {selectedListing && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setSelectedListing(null)}
              className="absolute inset-0 bg-brand-dark/80 backdrop-blur-sm"
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="relative w-full max-w-lg bg-brand-surface border border-white/10 rounded-[32px] p-8 shadow-2xl space-y-8"
            >
              <button 
                onClick={() => setSelectedListing(null)}
                className="absolute top-6 right-6 p-2 hover:bg-white/5 rounded-xl transition-colors"
              >
                <X className="w-5 h-5 text-gray-500" />
              </button>

              <div className="space-y-2">
                <div className="flex items-center gap-2 text-brand-primary">
                  <ShieldCheck className="w-5 h-5" />
                  <span className="text-xs font-bold uppercase tracking-widest">Secure Escrow Purchase</span>
                </div>
                <h2 className="text-3xl font-display font-black">Confirm Purchase</h2>
              </div>

              <div className="p-6 bg-brand-dark/50 rounded-2xl border border-white/5 flex items-center gap-4">
                <img 
                  src={selectedListing.image} 
                  alt="" 
                  className="w-20 h-20 rounded-xl object-cover border border-white/10"
                  referrerPolicy="no-referrer"
                />
                <div>
                  <h3 className="font-bold text-lg leading-tight">{selectedListing.title}</h3>
                  <p className="text-sm text-gray-500">{selectedListing.game}</p>
                  <div className="text-2xl font-display font-black text-brand-primary mt-1">${selectedListing.price}</div>
                </div>
              </div>

              <div className="space-y-4">
                <div className="flex items-start gap-3 p-4 bg-brand-primary/5 border border-brand-primary/20 rounded-2xl">
                  <AlertCircle className="w-5 h-5 text-brand-primary shrink-0 mt-0.5" />
                  <p className="text-xs text-gray-400 leading-relaxed">
                    By confirming, the funds will be held in <span className="text-brand-primary font-bold">JAKUB Escrow</span>. 
                    The seller will be notified to release the asset. Funds are only released to the seller after you confirm receipt.
                  </p>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <button 
                    onClick={() => setSelectedListing(null)}
                    className="py-4 bg-white/5 border border-white/10 rounded-2xl font-bold hover:bg-white/10 transition-all"
                  >
                    Cancel
                  </button>
                  <button 
                    onClick={handleConfirmPurchase}
                    disabled={isPurchasing}
                    className="py-4 bg-brand-primary text-brand-dark font-display font-black text-lg rounded-2xl hover:scale-[1.02] active:scale-[0.98] transition-all shadow-[0_0_20px_rgba(0,255,136,0.2)] disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    {isPurchasing ? 'Processing...' : 'Confirm & Chat'}
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
