import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Package, DollarSign, Gamepad2, Image as ImageIcon, ShieldCheck, ArrowLeft, TrendingUp, Loader2 } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { Listing } from '../types';
import { SELLER_TIERS } from '../constants';
import { supabase } from '../lib/supabaseClient';

interface SellPageProps {
  onAddListing: (listing: Listing) => void;
}

export default function SellPage() {
  const navigate = useNavigate();
  const currentTier = SELLER_TIERS[0]; // สมมติว่าเป็น IRON
  const [formData, setFormData] = useState({
    title: '',
    game: '',
    price: '',
    category: 'Item' as Listing['category'],
    description: '',
  });
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const estimatedIncome = formData.price 
    ? (parseFloat(formData.price) * (1 - currentTier.fee)).toFixed(2)
    : '0.00';

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setImageFile(file);
      const reader = new FileReader();
      reader.onloadend = () => setImagePreview(reader.result as string);
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    const { data: { user } } = await supabase.auth.getUser();
    if (!user) {
      alert('กรุณาล็อกอินก่อนลงขายสินค้า');
      navigate('/login');
      setIsSubmitting(false);
      return;
    }

    // 1. ตรวจสอบว่ามี profile หรือยัง
    const { data: profile, error: profileError } = await supabase
      .from('profiles')
      .select('id')
      .eq('id', user.id)
      .single();

    // 2. ถ้ายังไม่มี profile ให้สร้างให้
    if (profileError || !profile) {
      const { error: createProfileError } = await supabase
        .from('profiles')
        .insert([{ id: user.id, username: user.email?.split('@')[0] || 'user' }]);
      
      if (createProfileError) {
        console.error('Error creating profile:', createProfileError);
        alert('เกิดข้อผิดพลาดในการสร้างโปรไฟล์: ' + createProfileError.message);
        setIsSubmitting(false);
        return;
      }
    }

    // 3. อัปโหลดรูปภาพไปยัง Supabase Storage (ถ้ามี)
    let imageUrl = '';
    if (imageFile) {
      const fileExt = imageFile.name.split('.').pop();
      const fileName = `${user.id}-${Date.now()}.${fileExt}`;
      const { data: uploadData, error: uploadError } = await supabase.storage
        .from('product-images')
        .upload(fileName, imageFile);

      if (uploadError) {
        console.error('Image upload error:', uploadError);
        // ถ้าอัปโหลดไม่ได้ ให้ใช้รูป placeholder แทน
        imageUrl = `https://picsum.photos/seed/${Date.now()}/400/300`;
      } else {
        const { data: urlData } = supabase.storage
          .from('product-images')
          .getPublicUrl(fileName);
        imageUrl = urlData.publicUrl;
      }
    } else {
      imageUrl = `https://picsum.photos/seed/${Date.now()}/400/300`;
    }

    // 4. ทำการ insert สินค้า
    const { error } = await supabase
      .from('products')
      .insert([
        {
          name: formData.title,
          description: formData.description,
          price: parseFloat(formData.price),
          image_url: imageUrl,
          seller_id: user.id
        }
      ]);

    if (error) {
      console.error('Error inserting product:', error);
      alert('เกิดข้อผิดพลาด: ' + error.message);
    } else {
      alert('ลงขายสินค้าสำเร็จ!');
      navigate('/marketplace');
    }
    setIsSubmitting(false);
  };

  return (
    <div className="min-h-screen pt-24 pb-20 px-4">
      <div className="max-w-3xl mx-auto space-y-8">
        {/* ... (Link และ Header เดิม) */}

        <form onSubmit={handleSubmit} className="glass p-8 rounded-3xl border-white/10 space-y-6">
          {/* เพิ่มส่วนแสดงแรงค์และภาษี */}
          <div className="p-4 bg-brand-primary/10 border border-brand-primary/20 rounded-2xl flex items-center justify-between">
            <div className="flex items-center gap-3">
              <TrendingUp className="w-6 h-6 text-brand-primary" />
              <div>
                <p className="text-sm font-bold text-white">Current Tier: <span className="text-brand-primary">{currentTier.name}</span></p>
                <p className="text-xs text-gray-400">Sales Fee: {(currentTier.fee * 100).toFixed(0)}%</p>
              </div>
            </div>
            <div className="text-right">
              <p className="text-xs text-gray-400 uppercase tracking-wider">Estimated Income</p>
              <p className="text-xl font-display font-black text-white">฿{estimatedIncome}</p>
            </div>
          </div>

          {/* ... (Form Fields เดิม) */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <label className="text-sm font-bold text-gray-400 uppercase tracking-wider">Item Title</label>
              <div className="relative">
                <Package className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
                <input
                  required
                  type="text"
                  placeholder="e.g. Immortal 3 Account"
                  className="w-full bg-white/5 border border-white/10 rounded-xl py-3 pl-12 pr-4 focus:outline-none focus:ring-2 focus:ring-brand-primary/50 transition-all"
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                />
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-bold text-gray-400 uppercase tracking-wider">Game Name</label>
              <div className="relative">
                <Gamepad2 className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
                <input
                  required
                  type="text"
                  placeholder="e.g. Valorant"
                  className="w-full bg-white/5 border border-white/10 rounded-xl py-3 pl-12 pr-4 focus:outline-none focus:ring-2 focus:ring-brand-primary/50 transition-all"
                  value={formData.game}
                  onChange={(e) => setFormData({ ...formData, game: e.target.value })}
                />
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <label className="text-sm font-bold text-gray-400 uppercase tracking-wider">Price (USD)</label>
              <div className="relative">
                <DollarSign className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
                <input
                  required
                  type="number"
                  placeholder="0.00"
                  className="w-full bg-white/5 border border-white/10 rounded-xl py-3 pl-12 pr-4 focus:outline-none focus:ring-2 focus:ring-brand-primary/50 transition-all"
                  value={formData.price}
                  onChange={(e) => setFormData({ ...formData, price: e.target.value })}
                />
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-bold text-gray-400 uppercase tracking-wider">Category</label>
              <select
                className="w-full bg-white/5 border border-white/10 rounded-xl py-3 px-4 focus:outline-none focus:ring-2 focus:ring-brand-primary/50 transition-all appearance-none"
                value={formData.category}
                onChange={(e) => setFormData({ ...formData, category: e.target.value as Listing['category'] })}
              >
                <option value="Account">Account</option>
                <option value="Item">Item</option>
                <option value="Service">Service</option>
              </select>
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-bold text-gray-400 uppercase tracking-wider">Description</label>
            <textarea
              rows={4}
              placeholder="Describe your item in detail..."
              className="w-full bg-white/5 border border-white/10 rounded-xl py-3 px-4 focus:outline-none focus:ring-2 focus:ring-brand-primary/50 transition-all"
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
            />
          </div>

          <div className="space-y-2">
            <label className="text-sm font-bold text-gray-400 uppercase tracking-wider">Product Image</label>
            <div className="relative">
              <ImageIcon className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
              <input
                type="file"
                accept="image/*"
                className="w-full bg-white/5 border border-white/10 rounded-xl py-3 pl-12 pr-4 focus:outline-none focus:ring-2 focus:ring-brand-primary/50 transition-all file:mr-4 file:py-1 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-brand-primary file:text-brand-dark hover:file:bg-brand-primary/80"
                onChange={handleImageChange}
              />
            </div>
            {imagePreview && (
              <div className="mt-2">
                <img src={imagePreview} alt="Preview" className="w-32 h-32 object-cover rounded-xl" />
              </div>
            )}
          </div>

          <div className="pt-6">
            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full py-4 bg-brand-primary text-brand-dark font-bold rounded-2xl hover:scale-[1.02] active:scale-[0.98] transition-all flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isSubmitting ? (
                <><Loader2 className="w-5 h-5 animate-spin" /> กำลังดำเนินการ...</>
              ) : (
                <><ShieldCheck className="w-5 h-5" /> List Item for Sale</>
              )}
            </button>
            <p className="text-center text-xs text-gray-500 mt-4">
              By listing an item, you agree to our Terms of Service and Escrow Policy.
            </p>
          </div>
        </form>
      </div>
    </div>
  );
}
