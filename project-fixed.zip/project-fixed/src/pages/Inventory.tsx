import React from 'react';
import { 
  ArrowLeft, 
  Search, 
  Filter, 
  Plus, 
  Eye, 
  MoreVertical, 
  ShieldCheck,
  LayoutDashboard,
  Package,
  BarChart3,
  Wallet,
  Settings,
  HelpCircle,
  Clock,
  CheckCircle2,
  AlertCircle
} from 'lucide-react';
import { motion } from 'motion/react';
import { Link } from 'react-router-dom';
import { MOCK_ACTIVE_LISTINGS } from '../constants';
import { cn } from '../lib/utils';

export default function InventoryPage() {
  return (
    <div className="flex min-h-screen pt-16 bg-brand-dark">
      {/* Sidebar */}
      <div className="w-64 border-r border-white/5 bg-brand-surface/50 hidden lg:flex flex-col p-6 space-y-8">
        <Link to="/" className="flex items-center gap-3 px-2 group">
          <div className="w-10 h-10 bg-brand-primary/20 rounded-xl flex items-center justify-center group-hover:bg-brand-primary/30 transition-colors">
            <ShieldCheck className="text-brand-primary w-6 h-6" />
          </div>
          <div>
            <h3 className="font-bold text-sm">Jakub</h3>
            <p className="text-[10px] text-gray-500 font-bold uppercase tracking-widest">Verified Seller</p>
          </div>
        </Link>

        <nav className="space-y-2">
          <NavItem icon={LayoutDashboard} label="Dashboard" to="/seller-hub" />
          <NavItem icon={Package} label="Inventory" to="/inventory" active />
          <NavItem icon={BarChart3} label="Sales" to="/sell" />
          <NavItem icon={BarChart3} label="History" to="/sales-history" />
          <NavItem icon={Wallet} label="Payouts" to="/wallet" />
          <div className="pt-4 mt-4 border-t border-white/5">
            <Link to="/" className="w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all font-medium text-sm text-gray-400 hover:bg-white/5 hover:text-white">
              <ArrowLeft className="w-5 h-5" />
              Exit Seller Hub
            </Link>
          </div>
        </nav>

        <div className="pt-4">
          <Link to="/sell" className="w-full py-3 bg-brand-secondary text-white font-bold rounded-xl hover:scale-[1.02] transition-transform flex items-center justify-center gap-2 shadow-[0_0_20px_rgba(0,212,255,0.2)]">
            <Plus className="w-4 h-4" />
            List New Asset
          </Link>
        </div>

        <div className="mt-auto space-y-2">
          <NavItem icon={Settings} label="Settings" />
          <NavItem icon={HelpCircle} label="Support" />
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 p-8 overflow-y-auto">
        <div className="max-w-7xl mx-auto space-y-8">
          
          {/* Header */}
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="flex items-center gap-4">
              <Link to="/seller-hub" className="p-2 hover:bg-white/5 rounded-xl text-gray-400 transition-colors">
                <ArrowLeft className="w-5 h-5" />
              </Link>
              <div>
                <h1 className="text-2xl font-display font-black">My Inventory</h1>
                <p className="text-sm text-gray-500">Manage all your listed and sold items</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <Link to="/sell" className="flex items-center gap-2 px-6 py-3 bg-brand-primary text-brand-dark font-display font-black rounded-2xl hover:scale-105 transition-transform shadow-[0_0_20px_rgba(0,255,136,0.2)]">
                <Plus className="w-5 h-5" />
                List New Item
              </Link>
            </div>
          </div>

          {/* Filters & Tabs */}
          <div className="flex flex-col md:flex-row gap-4 items-center justify-between">
            <div className="flex bg-white/5 rounded-2xl p-1">
              <button className="px-6 py-2 text-sm font-bold rounded-xl bg-brand-primary/20 text-brand-primary">All Items</button>
              <button className="px-6 py-2 text-sm font-bold rounded-xl text-gray-500 hover:text-gray-300">Active</button>
              <button className="px-6 py-2 text-sm font-bold rounded-xl text-gray-500 hover:text-gray-300">Sold</button>
            </div>
            <div className="relative w-full md:w-64">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
              <input 
                type="text" 
                placeholder="Search inventory..."
                className="w-full bg-brand-surface border border-white/10 rounded-2xl py-3 pl-12 pr-4 text-sm focus:outline-none focus:ring-2 focus:ring-brand-primary/50 transition-all"
              />
            </div>
          </div>

          {/* Inventory Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
            {MOCK_ACTIVE_LISTINGS.map((item) => (
              <motion.div 
                key={item.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="bg-brand-surface border border-white/5 rounded-[32px] overflow-hidden group hover:border-brand-primary/30 transition-all"
              >
                <div className="relative aspect-video overflow-hidden">
                  <img src={item.image} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" alt="" />
                  <div className="absolute top-4 right-4">
                    <div className={cn(
                      "px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider backdrop-blur-md border",
                      item.status === 'Active' ? "bg-brand-primary/20 border-brand-primary/30 text-brand-primary" :
                      item.status === 'Sold' ? "bg-brand-secondary/20 border-brand-secondary/30 text-brand-secondary" :
                      "bg-purple-500/20 border-purple-500/30 text-purple-400"
                    )}>
                      {item.status}
                    </div>
                  </div>
                </div>
                <div className="p-6 space-y-4">
                  <div className="flex justify-between items-start">
                    <div>
                      <h3 className="font-bold text-lg">{item.title}</h3>
                      <p className="text-xs text-gray-500 uppercase tracking-widest font-bold">{item.game}</p>
                    </div>
                    <button className="p-2 hover:bg-white/5 rounded-xl transition-colors">
                      <MoreVertical className="w-4 h-4 text-gray-500" />
                    </button>
                  </div>
                  
                  <div className="flex items-center justify-between pt-2">
                    <div>
                      <p className="text-[10px] text-gray-500 uppercase font-bold">Price</p>
                      <p className="text-2xl font-display font-black text-brand-primary">${item.price.toFixed(2)}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-[10px] text-gray-500 uppercase font-bold">Views</p>
                      <div className="flex items-center gap-1.5 text-gray-300 font-bold">
                        <Eye className="w-4 h-4" />
                        <span>{(item.views / 1000).toFixed(1)}k</span>
                      </div>
                    </div>
                  </div>

                  <div className="pt-4 flex gap-3">
                    {item.status === 'Active' ? (
                      <>
                        <button className="flex-1 py-3 bg-brand-primary text-brand-dark font-bold rounded-xl hover:scale-105 transition-transform">
                          Edit Listing
                        </button>
                        <button className="px-4 py-3 bg-white/5 border border-white/10 rounded-xl hover:bg-white/10 transition-colors">
                          <AlertCircle className="w-5 h-5 text-gray-400" />
                        </button>
                      </>
                    ) : (
                      <button className="w-full py-3 bg-white/5 border border-white/10 rounded-xl text-sm font-bold hover:bg-white/10 transition-colors flex items-center justify-center gap-2">
                        View Order Details
                        <ArrowLeft className="w-4 h-4 rotate-180" />
                      </button>
                    )}
                  </div>
                </div>
              </motion.div>
            ))}
          </div>

        </div>
      </div>
    </div>
  );
}

function NavItem({ icon: Icon, label, to = "#", active = false }: { icon: any, label: string, to?: string, active?: boolean }) {
  return (
    <Link to={to} className={cn(
      "w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all font-medium text-sm",
      active ? "bg-brand-primary/10 text-brand-primary border border-brand-primary/20" : "text-gray-400 hover:bg-white/5"
    )}>
      <Icon className="w-5 h-5" />
      {label}
    </Link>
  );
}
