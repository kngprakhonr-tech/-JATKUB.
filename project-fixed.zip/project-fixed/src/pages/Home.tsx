import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Search, ShieldCheck, Gamepad2, ChevronRight, Star, ShoppingCart, X, AlertCircle } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { Listing } from '../types';
import { CATEGORIES } from '../constants';
import { cn } from '../lib/utils';

interface HomePageProps {
  trendingListings: Listing[];
}

interface ListingCardProps {
  listing: Listing;
  onBuy: (listing: Listing) => void;
  key?: string;
}

const ListingCard = ({ listing, onBuy }: ListingCardProps) => {
  return (
    <motion.div
      whileHover={{ y: -8 }}
      className="group bg-brand-surface border border-white/5 rounded-2xl overflow-hidden hover:border-brand-primary/30 transition-all"
    >
      <div className="relative aspect-[4/3] overflow-hidden">
        <img 
          src={listing.image} 
          alt={listing.title}
          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
          referrerPolicy="no-referrer"
        />
        <div className="absolute top-3 left-3 px-2 py-1 bg-black/60 backdrop-blur-md rounded-lg text-[10px] font-bold uppercase tracking-wider">
          {listing.game}
        </div>
        <div className="absolute top-3 right-3 p-2 bg-brand-primary text-brand-dark rounded-lg shadow-lg">
          <ShoppingCart className="w-4 h-4" />
        </div>
      </div>
      
      <div className="p-5 space-y-4">
        <div className="space-y-1">
          <div className="text-xs text-brand-primary font-bold uppercase tracking-widest">{listing.category}</div>
          <h3 className="text-lg font-display font-bold leading-tight line-clamp-2 group-hover:text-brand-primary transition-colors">
            {listing.title}
          </h3>
        </div>

        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 bg-white/10 rounded-full" />
            <span className="text-sm text-gray-400">{listing.seller}</span>
          </div>
          <div className="flex items-center gap-1 text-yellow-500">
            <Star className="w-3 h-3 fill-current" />
            <span className="text-xs font-bold">{listing.rating}</span>
          </div>
        </div>

        <div className="pt-4 border-t border-white/5 flex items-center justify-between">
          <div className="text-2xl font-display font-black">${listing.price}</div>
          <button 
            onClick={() => onBuy(listing)}
            className="flex items-center gap-1 text-sm font-bold text-brand-primary group-hover:gap-2 transition-all"
          >
            Buy Now <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </motion.div>
  );
};

export default function HomePage({ trendingListings }: HomePageProps) {
  const [selectedListing, setSelectedListing] = useState<Listing | null>(null);
  const navigate = useNavigate();

  const handleConfirmPurchase = () => {
    setSelectedListing(null);
    navigate('/messages');
  };

  return (
    <div className="min-h-screen">
      {/* Hero */}
      <section className="relative pt-32 pb-20 px-4 overflow-hidden">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-4xl h-full bg-brand-primary/10 blur-[120px] -z-10" />
        <div className="absolute bottom-0 right-0 w-96 h-96 bg-brand-secondary/10 blur-[100px] -z-10" />

        <div className="max-w-4xl mx-auto text-center space-y-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-brand-primary/10 border border-brand-primary/20 text-brand-primary text-xs font-bold uppercase tracking-widest"
          >
            <ShieldCheck className="w-3 h-3" />
            Escrow Protected Marketplace
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-5xl md:text-7xl font-display font-black leading-[1.1] tracking-tight"
          >
            Level Up Your <br />
            <span className="gradient-text">Gaming Experience</span>
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="text-gray-400 text-lg md:text-xl max-w-2xl mx-auto"
          >
            The most secure platform to buy and sell gaming accounts, items, and professional services.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="relative max-w-2xl mx-auto"
          >
            <div className="absolute inset-y-0 left-4 flex items-center pointer-events-none">
              <Search className="text-gray-500 w-5 h-5" />
            </div>
            <input 
              type="text" 
              placeholder="Search for games, accounts, or items..."
              className="w-full bg-white/5 border border-white/10 rounded-2xl py-4 pl-12 pr-32 focus:outline-none focus:ring-2 focus:ring-brand-primary/50 transition-all text-lg"
            />
            <Link to="/marketplace" className="absolute right-2 top-2 bottom-2 px-6 bg-brand-primary text-brand-dark font-bold rounded-xl hover:scale-105 transition-transform flex items-center">
              Search
            </Link>
          </motion.div>
        </div>
      </section>

      {/* Categories */}
      <section className="max-w-7xl mx-auto px-4 py-8">
        <div className="flex items-center gap-4 overflow-x-auto pb-4 no-scrollbar">
          {CATEGORIES.map((cat) => (
            <Link
              key={cat.name}
              to={`/marketplace?category=${cat.name}`}
              className="flex items-center gap-2 px-6 py-3 rounded-xl border bg-white/5 border-white/10 text-gray-400 hover:border-white/20 transition-all whitespace-nowrap font-medium"
            >
              <cat.icon className="w-4 h-4" />
              {cat.name}
            </Link>
          ))}
        </div>
      </section>

      {/* Trending */}
      <section className="max-w-7xl mx-auto px-4 py-12">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h2 className="text-3xl font-display font-bold">Trending Listings</h2>
            <p className="text-gray-500">Most popular items in the last 24 hours</p>
          </div>
          <Link to="/marketplace" className="text-brand-primary font-bold flex items-center gap-2 hover:underline">
            View All <ChevronRight className="w-4 h-4" />
          </Link>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {trendingListings.map((listing) => (
            <ListingCard 
              key={listing.id} 
              listing={listing} 
              onBuy={(l) => setSelectedListing(l)}
            />
          ))}
        </div>
      </section>

      {/* CTA */}
      <section className="max-w-7xl mx-auto px-4 py-20">
        <div className="relative rounded-3xl overflow-hidden bg-gradient-to-br from-brand-primary/20 to-brand-secondary/20 border border-white/10 p-12 text-center">
          <div className="absolute top-0 left-0 w-full h-full bg-[url('https://picsum.photos/seed/pattern/1920/1080')] opacity-10 mix-blend-overlay" />
          <div className="relative space-y-6">
            <h2 className="text-4xl md:text-5xl font-display font-black">Ready to Start Selling?</h2>
            <p className="text-gray-300 text-lg max-w-xl mx-auto">
              Join thousands of sellers and start earning from your gaming skills and assets today.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-4">
              <Link to="/sell" className="w-full sm:w-auto px-8 py-4 bg-brand-primary text-brand-dark font-bold rounded-2xl hover:scale-105 transition-transform">
                Start Selling Now
              </Link>
              <Link to="/marketplace" className="w-full sm:w-auto px-8 py-4 bg-white/5 border border-white/10 font-bold rounded-2xl hover:bg-white/10 transition-all">
                Learn More
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Purchase Confirmation Modal */}
      <AnimatePresence>
        {selectedListing && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setSelectedListing(null)}
              className="absolute inset-0 bg-brand-dark/80 backdrop-blur-sm"
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="relative w-full max-w-lg bg-brand-surface border border-white/10 rounded-[32px] p-8 shadow-2xl space-y-8"
            >
              <button 
                onClick={() => setSelectedListing(null)}
                className="absolute top-6 right-6 p-2 hover:bg-white/5 rounded-xl transition-colors"
              >
                <X className="w-5 h-5 text-gray-500" />
              </button>

              <div className="space-y-2">
                <div className="flex items-center gap-2 text-brand-primary">
                  <ShieldCheck className="w-5 h-5" />
                  <span className="text-xs font-bold uppercase tracking-widest">Secure Escrow Purchase</span>
                </div>
                <h2 className="text-3xl font-display font-black">Confirm Purchase</h2>
              </div>

              <div className="p-6 bg-brand-dark/50 rounded-2xl border border-white/5 flex items-center gap-4">
                <img 
                  src={selectedListing.image} 
                  alt="" 
                  className="w-20 h-20 rounded-xl object-cover border border-white/10"
                  referrerPolicy="no-referrer"
                />
                <div>
                  <h3 className="font-bold text-lg leading-tight">{selectedListing.title}</h3>
                  <p className="text-sm text-gray-500">{selectedListing.game}</p>
                  <div className="text-2xl font-display font-black text-brand-primary mt-1">${selectedListing.price}</div>
                </div>
              </div>

              <div className="space-y-4">
                <div className="flex items-start gap-3 p-4 bg-brand-primary/5 border border-brand-primary/20 rounded-2xl">
                  <AlertCircle className="w-5 h-5 text-brand-primary shrink-0 mt-0.5" />
                  <p className="text-xs text-gray-400 leading-relaxed">
                    By confirming, the funds will be held in <span className="text-brand-primary font-bold">JAKUB Escrow</span>. 
                    The seller will be notified to release the asset. Funds are only released to the seller after you confirm receipt.
                  </p>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <button 
                    onClick={() => setSelectedListing(null)}
                    className="py-4 bg-white/5 border border-white/10 rounded-2xl font-bold hover:bg-white/10 transition-all"
                  >
                    Cancel
                  </button>
                  <button 
                    onClick={handleConfirmPurchase}
                    className="py-4 bg-brand-primary text-brand-dark font-display font-black text-lg rounded-2xl hover:scale-[1.02] active:scale-[0.98] transition-all shadow-[0_0_20px_rgba(0,255,136,0.2)]"
                  >
                    Confirm & Chat
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
