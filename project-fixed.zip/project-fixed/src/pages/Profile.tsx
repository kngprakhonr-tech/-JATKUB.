import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { User, Mail, ShieldCheck, Save, AlertCircle } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { supabase } from '../lib/supabaseClient';
import { cn } from '../lib/utils';

export default function ProfilePage() {
  const { user } = useAuth();
  const [username, setUsername] = useState('');
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState<{ type: 'success' | 'error', text: string } | null>(null);

  useEffect(() => {
    if (user) {
      // ดึงข้อมูลโปรไฟล์จากตาราง public.profiles
      supabase
        .from('profiles')
        .select('username')
        .eq('id', user.id)
        .single()
        .then(({ data, error }) => {
          if (data) setUsername(data.username || '');
        });
    }
  }, [user]);

  const handleUpdateProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setMessage(null);

    try {
      const { error } = await supabase
        .from('profiles')
        .upsert({ id: user?.id, username });

      if (error) throw error;
      setMessage({ type: 'success', text: 'อัปเดตโปรไฟล์สำเร็จ!' });
    } catch (err: any) {
      setMessage({ type: 'error', text: err.message });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-brand-dark p-6">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="max-w-2xl mx-auto bg-brand-surface/50 backdrop-blur-xl border border-white/5 rounded-[40px] p-10 space-y-8 shadow-2xl"
      >
        <h1 className="text-3xl font-display font-black">My Profile</h1>
        
        {message && (
          <div className={cn("p-4 rounded-2xl text-sm flex items-center gap-2", message.type === 'success' ? "bg-green-500/10 border border-green-500/20 text-green-500" : "bg-red-500/10 border border-red-500/20 text-red-500")}>
            <AlertCircle className="w-4 h-4" />
            {message.text}
          </div>
        )}

        <form onSubmit={handleUpdateProfile} className="space-y-6">
          <div className="space-y-2">
            <label className="text-[10px] font-bold text-gray-500 uppercase tracking-widest ml-1">Email</label>
            <div className="relative">
              <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
              <input 
                type="email" 
                value={user?.email}
                disabled
                className="w-full bg-brand-dark/50 border border-white/5 rounded-2xl py-4 pl-12 pr-4 text-sm font-medium text-gray-400"
              />
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-[10px] font-bold text-gray-500 uppercase tracking-widest ml-1">Username</label>
            <div className="relative">
              <User className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
              <input 
                type="text" 
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="Enter your username"
                className="w-full bg-brand-dark/50 border border-white/5 rounded-2xl py-4 pl-12 pr-4 focus:outline-none focus:ring-2 focus:ring-brand-primary/50 transition-all text-sm font-medium"
              />
            </div>
          </div>

          <button 
            type="submit"
            disabled={loading}
            className="w-full py-5 bg-brand-primary text-brand-dark font-display font-black text-xl rounded-2xl hover:scale-[1.02] active:scale-[0.98] transition-all shadow-[0_0_30px_rgba(0,212,255,0.2)] disabled:opacity-50"
          >
            {loading ? 'SAVING...' : 'SAVE PROFILE'}
          </button>
        </form>
      </motion.div>
    </div>
  );
}
