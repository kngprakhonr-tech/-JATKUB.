import React from 'react';
import { 
  ArrowLeft, 
  Search, 
  Filter, 
  Download, 
  ExternalLink, 
  CheckCircle2, 
  XCircle, 
  Clock,
  ShieldCheck,
  LayoutDashboard,
  Package,
  BarChart3,
  Wallet,
  Settings,
  HelpCircle,
  Plus
} from 'lucide-react';
import { motion } from 'motion/react';
import { Link } from 'react-router-dom';
import { MOCK_SALES_HISTORY } from '../constants';
import { cn } from '../lib/utils';

export default function SalesHistoryPage() {
  return (
    <div className="flex min-h-screen pt-16 bg-brand-dark">
      {/* Sidebar */}
      <div className="w-64 border-r border-white/5 bg-brand-surface/50 hidden lg:flex flex-col p-6 space-y-8">
        <Link to="/" className="flex items-center gap-3 px-2 group">
          <div className="w-10 h-10 bg-brand-primary/20 rounded-xl flex items-center justify-center group-hover:bg-brand-primary/30 transition-colors">
            <ShieldCheck className="text-brand-primary w-6 h-6" />
          </div>
          <div>
            <h3 className="font-bold text-sm">Jakub</h3>
            <p className="text-[10px] text-gray-500 font-bold uppercase tracking-widest">Verified Seller</p>
          </div>
        </Link>

        <nav className="space-y-2">
          <NavItem icon={LayoutDashboard} label="Dashboard" to="/seller-hub" />
          <NavItem icon={Package} label="Inventory" to="/inventory" />
          <NavItem icon={BarChart3} label="Sales" to="/sell" />
          <NavItem icon={BarChart3} label="History" to="/sales-history" active />
          <NavItem icon={Wallet} label="Payouts" to="/wallet" />
          <div className="pt-4 mt-4 border-t border-white/5">
            <Link to="/" className="w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all font-medium text-sm text-gray-400 hover:bg-white/5 hover:text-white">
              <ArrowLeft className="w-5 h-5" />
              Exit Seller Hub
            </Link>
          </div>
        </nav>

        <div className="pt-4">
          <Link to="/sell" className="w-full py-3 bg-brand-secondary text-white font-bold rounded-xl hover:scale-[1.02] transition-transform flex items-center justify-center gap-2 shadow-[0_0_20px_rgba(0,212,255,0.2)]">
            <Plus className="w-4 h-4" />
            List New Asset
          </Link>
        </div>

        <div className="mt-auto space-y-2">
          <NavItem icon={Settings} label="Settings" />
          <NavItem icon={HelpCircle} label="Support" />
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 p-8 overflow-y-auto">
        <div className="max-w-7xl mx-auto space-y-8">
          
          {/* Header */}
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="flex items-center gap-4">
              <Link to="/seller-hub" className="p-2 hover:bg-white/5 rounded-xl text-gray-400 transition-colors">
                <ArrowLeft className="w-5 h-5" />
              </Link>
              <div>
                <h1 className="text-2xl font-display font-black">Sales History</h1>
                <p className="text-sm text-gray-500">Track all your completed and pending sales</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <button className="flex items-center gap-2 px-4 py-2 bg-white/5 border border-white/10 rounded-xl text-xs font-bold hover:bg-white/10 transition-colors">
                <Download className="w-4 h-4" />
                Export CSV
              </button>
            </div>
          </div>

          {/* Filters & Search */}
          <div className="flex flex-col md:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
              <input 
                type="text" 
                placeholder="Search by item name or buyer..."
                className="w-full bg-brand-surface border border-white/10 rounded-2xl py-3 pl-12 pr-4 text-sm focus:outline-none focus:ring-2 focus:ring-brand-primary/50 transition-all"
              />
            </div>
            <div className="flex gap-3">
              <button className="flex items-center gap-2 px-4 py-3 bg-brand-surface border border-white/10 rounded-2xl text-sm font-bold hover:bg-white/5 transition-colors">
                <Filter className="w-4 h-4" />
                Filter
              </button>
              <select className="bg-brand-surface border border-white/10 rounded-2xl px-4 py-3 text-sm font-bold focus:outline-none focus:ring-2 focus:ring-brand-primary/50 transition-all">
                <option>Last 30 Days</option>
                <option>Last 90 Days</option>
                <option>Year 2023</option>
                <option>All Time</option>
              </select>
            </div>
          </div>

          {/* History Table */}
          <div className="bg-brand-surface border border-white/5 rounded-[32px] overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="text-[10px] font-bold text-gray-500 uppercase tracking-widest border-b border-white/5">
                    <th className="text-left p-6">Item Details</th>
                    <th className="text-left p-6">Buyer</th>
                    <th className="text-left p-6">Date</th>
                    <th className="text-left p-6">Amount</th>
                    <th className="text-left p-6">Status</th>
                    <th className="text-right p-6">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5">
                  {MOCK_SALES_HISTORY.map((sale) => (
                    <tr key={sale.id} className="group hover:bg-white/5 transition-colors">
                      <td className="p-6">
                        <div className="flex items-center gap-4">
                          <img src={sale.image} className="w-12 h-12 rounded-xl bg-white/5 object-cover" alt="" />
                          <div>
                            <p className="font-bold text-sm">{sale.item}</p>
                            <p className="text-[10px] text-gray-500 uppercase tracking-widest">Order #{sale.id}</p>
                          </div>
                        </div>
                      </td>
                      <td className="p-6">
                        <div className="flex items-center gap-2">
                          <div className="w-6 h-6 bg-white/10 rounded-full" />
                          <span className="text-sm font-medium">{sale.buyer}</span>
                        </div>
                      </td>
                      <td className="p-6 text-sm text-gray-400">{sale.date}</td>
                      <td className="p-6">
                        <span className="font-display font-black text-brand-primary text-lg">${sale.price.toFixed(2)}</span>
                      </td>
                      <td className="p-6">
                        <div className={cn(
                          "inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider",
                          sale.status === 'Completed' ? "bg-green-500/10 text-green-500" :
                          sale.status === 'Refunded' ? "bg-red-500/10 text-red-500" :
                          "bg-yellow-500/10 text-yellow-500"
                        )}>
                          {sale.status === 'Completed' && <CheckCircle2 className="w-3 h-3" />}
                          {sale.status === 'Refunded' && <XCircle className="w-3 h-3" />}
                          {sale.status === 'Cancelled' && <Clock className="w-3 h-3" />}
                          {sale.status}
                        </div>
                      </td>
                      <td className="p-6 text-right">
                        <button className="p-2 hover:bg-brand-primary/10 rounded-lg transition-colors text-gray-500 hover:text-brand-primary">
                          <ExternalLink className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            
            {/* Pagination */}
            <div className="p-6 border-t border-white/5 flex items-center justify-between">
              <p className="text-xs text-gray-500">Showing 1 to 4 of 24 transactions</p>
              <div className="flex gap-2">
                <button className="px-4 py-2 bg-white/5 border border-white/10 rounded-xl text-xs font-bold opacity-50 cursor-not-allowed">Previous</button>
                <button className="px-4 py-2 bg-white/5 border border-white/10 rounded-xl text-xs font-bold hover:bg-white/10 transition-colors">Next</button>
              </div>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
}

function NavItem({ icon: Icon, label, to = "#", active = false }: { icon: any, label: string, to?: string, active?: boolean }) {
  return (
    <Link to={to} className={cn(
      "w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all font-medium text-sm",
      active ? "bg-brand-primary/10 text-brand-primary border border-brand-primary/20" : "text-gray-400 hover:bg-white/5"
    )}>
      <Icon className="w-5 h-5" />
      {label}
    </Link>
  );
}
