import { Globe, User, Gamepad2, Zap, TrendingUp } from 'lucide-react';
import { Listing, Chat } from './types';

export const CATEGORIES = [
  { name: 'All', icon: Globe },
  { name: 'Accounts', icon: User },
  { name: 'Items', icon: Gamepad2 },
  { name: 'Boosting', icon: Zap },
  { name: 'Currency', icon: TrendingUp },
] as const;

export const INITIAL_LISTINGS: Listing[] = [
  {
    id: '1',
    title: 'Immortal 3 Account - All Agents Unlocked',
    game: 'Valorant',
    price: 120,
    seller: 'ProGamer99',
    rating: 4.9,
    image: 'https://picsum.photos/seed/valorant/400/300',
    category: 'Account',
    description: 'High-rank Valorant account with all agents unlocked and several premium skins. Ready for competitive play.',
  },
  {
    id: '2',
    title: 'Dragonclaw Hook - Clean',
    game: 'Dota 2',
    price: 850,
    seller: 'TraderJoe',
    rating: 5.0,
    image: 'https://picsum.photos/seed/dota2/400/300',
    category: 'Item',
    description: 'A clean Dragonclaw Hook for Pudge. Highly sought after by collectors.',
  },
  {
    id: '3',
    title: 'Elden Ring Runes - 99M Stack',
    game: 'Elden Ring',
    price: 15,
    seller: 'SoulsMaster',
    rating: 4.8,
    image: 'https://picsum.photos/seed/elden/400/300',
    category: 'Item',
    description: '99 million runes to level up your character quickly. Delivered instantly in-game.',
  },
  {
    id: '4',
    title: 'Rank Reset Service - Guaranteed Win',
    game: 'League of Legends',
    price: 45,
    seller: 'EloKing',
    rating: 4.7,
    image: 'https://picsum.photos/seed/lol/400/300',
    category: 'Service',
    description: 'Professional rank reset service. We guarantee a win in your next placement matches.',
  },
];

import { Transaction } from './types';

export const MOCK_TRANSACTIONS: Transaction[] = [
  {
    id: 't1',
    type: 'Withdraw',
    amount: 1200,
    method: 'Chase Bank •••• 8821',
    status: 'Completed',
    timestamp: 'Oct 24, 2023 • 14:20',
    description: 'Withdrawal to Bank Account',
  },
  {
    id: 't2',
    type: 'Withdraw',
    amount: 500,
    method: 'Chase Bank •••• 8821',
    status: 'Pending',
    timestamp: 'Just now',
    description: 'Withdrawal to Bank Account',
  },
  {
    id: 't3',
    type: 'Withdraw',
    amount: 250,
    method: 'PayPal Wallet',
    status: 'Rejected',
    timestamp: 'Oct 20, 2023 • 09:12',
    description: 'Withdrawal to PayPal',
  },
  {
    id: 't4',
    type: 'Deposit',
    amount: 50,
    method: 'Credit Card',
    status: 'Completed',
    timestamp: 'Oct 15, 2023',
    description: 'Deposit (Card)',
  },
  {
    id: 't5',
    type: 'Purchase',
    amount: 120,
    status: 'Completed',
    timestamp: 'Oct 12, 2023',
    description: 'Valorant Skin',
  },
];

import { SellerStats, ActiveListing, EscrowTransaction, SalesHistoryItem } from './types';

export const MOCK_SALES_HISTORY: SalesHistoryItem[] = [
  {
    id: 'sh1',
    item: 'Dragon Slayer #402',
    buyer: 'ShadowGamer99',
    price: 450.00,
    date: 'Oct 24, 2023',
    status: 'Completed',
    image: 'https://picsum.photos/seed/valorant-skin/100/100',
  },
  {
    id: 'sh2',
    item: 'Void Axe MK-II',
    buyer: 'NeonRider_X',
    price: 890.00,
    date: 'Oct 22, 2023',
    status: 'Completed',
    image: 'https://picsum.photos/seed/dota-weapon/100/100',
  },
  {
    id: 'sh3',
    item: 'Cyber Punk V3',
    buyer: 'EliteGamer',
    price: 1200.00,
    date: 'Oct 20, 2023',
    status: 'Refunded',
    image: 'https://picsum.photos/seed/cyberpunk-bundle/100/100',
  },
  {
    id: 'sh4',
    item: 'Golden Deagle Skin',
    buyer: 'ProSniper88',
    price: 85.00,
    date: 'Oct 18, 2023',
    status: 'Completed',
    image: 'https://picsum.photos/seed/deagle/100/100',
  },
];

export const MOCK_SELLER_STATS: SellerStats = {
  totalEarnings: 24850.42,
  pendingPayouts: 4120.00,
  earningsGrowth: 12.5,
  nextReleaseTime: '2h 45m',
};

export const MOCK_REVENUE_DATA = [
  { date: 'Oct 01', revenue: 1500 },
  { date: 'Oct 02', revenue: 1800 },
  { date: 'Oct 03', revenue: 2200 },
  { date: 'Oct 04', revenue: 2800 },
  { date: 'Oct 05', revenue: 2400 },
  { date: 'Oct 06', revenue: 3100 },
  { date: 'Oct 07', revenue: 2600 },
  { date: 'Oct 08', revenue: 3400 },
  { date: 'Oct 09', revenue: 3200 },
  { date: 'Oct 10', revenue: 4500 },
  { date: 'Oct 11', revenue: 3800 },
  { date: 'Oct 12', revenue: 3300 },
  { date: 'Oct 13', revenue: 3600 },
  { date: 'Oct 14', revenue: 4200 },
];

export const MOCK_ACTIVE_LISTINGS: ActiveListing[] = [
  {
    id: 'al1',
    title: 'Dragon Slayer #402',
    game: 'Valorant',
    price: 450.00,
    views: 1200,
    image: 'https://picsum.photos/seed/valorant-skin/100/100',
    status: 'Active',
  },
  {
    id: 'al2',
    title: 'Void Axe MK-II',
    game: 'Dota 2',
    price: 890.00,
    views: 842,
    image: 'https://picsum.photos/seed/dota-weapon/100/100',
    status: 'Sold',
  },
  {
    id: 'al3',
    title: 'Cyber Punk V3',
    game: 'Cyberpunk',
    price: 1200.00,
    views: 2400,
    image: 'https://picsum.photos/seed/cyberpunk-bundle/100/100',
    status: 'In Escrow',
  },
];

export const MOCK_ESCROW_TRANSACTIONS: EscrowTransaction[] = [
  {
    id: 'et1',
    buyer: 'ShadowGamer99',
    item: 'Midnight Scythe (Rare)',
    price: 320.00,
    status: 'Asset Delivered',
    step: 2,
    totalSteps: 3,
  },
  {
    id: 'et2',
    buyer: 'NeonRider_X',
    item: 'Dragonic War Mount (Ultra Rare)',
    price: 1500.00,
    status: 'Awaiting Confirmation',
    step: 1,
    totalSteps: 3,
  },
  {
    id: 'et3',
    buyer: 'ProSniper88',
    item: 'Golden Deagle Skin',
    price: 85.00,
    status: 'Funds Releasing',
    step: 3,
    totalSteps: 3,
  },
];

export const MOCK_CHATS: Chat[] = [
  {
    id: 'chat_1',
    participant: {
      name: 'Donoff2100',
      avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Donoff',
      status: 'active in trade',
    },
    role: 'buyer',
    lastMessage: 'The account details are ready.',
    lastMessageTime: '14:02',
    messages: [
      {
        id: 'm1',
        senderId: 'Donoff2100',
        text: "Hey Jakub, I'm interested in the Roblox Account you listed. Can we finalize the escrow?",
        timestamp: '13:45',
        isMe: false,
      },
      {
        id: 'm2',
        senderId: 'me',
        text: "Absolutely. The price is fixed at $7.32. Once you initiate the escrow, I'll release the login credentials immediately.",
        timestamp: '13:48',
        isMe: true,
      },
      {
        id: 'm3',
        senderId: 'Donoff2100',
        text: "Perfect. I just sent the payment to the Bastion Escrow. Can you verify?",
        timestamp: '14:01',
        isMe: false,
      },
      {
        id: 'm4',
        senderId: 'me',
        text: "Checking now... Yes, I see it. The account details are ready.",
        timestamp: '14:02',
        isMe: true,
      },
    ],
    orderDetail: {
      itemTitle: 'Roblox Account [Elite]',
      itemImage: 'https://picsum.photos/seed/roblox/400/300',
      price: 7.32,
      status: 'In Escrow',
    },
  },
  {
    id: 'chat_2',
    participant: {
      name: 'CipherX',
      avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Cipher',
      status: 'online',
    },
    role: 'buyer',
    lastMessage: 'Trade completed successfully.',
    lastMessageTime: 'Yesterday',
    messages: [],
  },
  {
    id: 'chat_3',
    participant: {
      name: 'GhostRider',
      avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Ghost',
      status: 'offline',
    },
    role: 'buyer',
    lastMessage: 'Is the CS:GO knife still available?',
    lastMessageTime: 'Jan 12',
    messages: [],
  },
  {
    id: 'chat_4',
    participant: {
      name: 'ProSniper88',
      avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Sniper',
      status: 'active in trade',
    },
    role: 'seller',
    lastMessage: 'I have sent the item.',
    lastMessageTime: '10:30',
    messages: [
      {
        id: 'sm1',
        senderId: 'me',
        text: "Hi, I just bought the Golden Deagle Skin.",
        timestamp: '10:15',
        isMe: true,
      },
      {
        id: 'sm2',
        senderId: 'ProSniper88',
        text: "Got it! I have sent the item to your account.",
        timestamp: '10:30',
        isMe: false,
      }
    ],
    orderDetail: {
      itemTitle: 'Golden Deagle Skin',
      itemImage: 'https://picsum.photos/seed/deagle/400/300',
      price: 85.00,
      status: 'Funds Releasing',
    },
  },
  {
    id: 'chat_5',
    participant: {
      name: 'EliteTrader',
      avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Elite',
      status: 'online',
    },
    role: 'seller',
    lastMessage: 'Let me know when you are ready.',
    lastMessageTime: '09:00',
    messages: [],
  }
];

export const SELLER_TIERS = [
  { name: 'IRON', fee: 0.10 },
  { name: 'BRONZE', fee: 0.09 },
  { name: 'SILVER', fee: 0.08 },
  { name: 'GOLD', fee: 0.07 },
  { name: 'PLATINUM', fee: 0.06 },
  { name: 'VIBRANIUM', fee: 0.05 },
];
