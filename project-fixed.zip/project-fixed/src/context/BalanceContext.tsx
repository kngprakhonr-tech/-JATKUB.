import React, { createContext, useContext, useState, useEffect } from 'react';
import { supabase } from '../lib/supabaseClient';

const BalanceContext = createContext<{
  balance: number | null;
  refreshBalance: () => Promise<void>;
}>({
  balance: null,
  refreshBalance: async () => {},
});

export const BalanceProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [balance, setBalance] = useState<number | null>(null);

  const refreshBalance = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    const { data, error } = await supabase
      .from('wallets')
      .select('balance')
      .eq('user_id', user.id)
      .single();

    if (data) {
      setBalance(data.balance);
    } else if (error && error.code === 'PGRST116') {
      // ถ้าไม่มีกระเป๋าเงิน ให้ตั้งเป็น 0
      setBalance(0);
    }
  };

  useEffect(() => {
    refreshBalance();
  }, []);

  return (
    <BalanceContext.Provider value={{ balance, refreshBalance }}>
      {children}
    </BalanceContext.Provider>
  );
};

export const useBalance = () => useContext(BalanceContext);
